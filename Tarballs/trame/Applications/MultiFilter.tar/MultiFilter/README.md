# VTK Mutli Filter Example

![VTK Multi Filter Example](../../../../docs/content/examples/MultiFilter.jpg)
