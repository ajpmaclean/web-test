### Description

This example illustrates basic usage of VTK with trame.

Things you can do:

- Add some color using vtkNamedColors to the actor and background.
- Use a different source e.g. vtkCylinderSource instead of vtkConeSource.

See: [Cone](../../../../Python/GeometricObjects/Cone) for some ideas.
