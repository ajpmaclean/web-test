#include <vtkActor.h>
#include <vtkCallbackCommand.h>
#include <vtkCamera.h>
#include <vtkContourFilter.h>
#include <vtkGenericOutlineFilter.h>
#include <vtkInteractorStyleSwitch.h>
#include <vtkInteractorStyleTrackballCamera.h>
#include <vtkNamedColors.h>
#include <vtkNew.h>
#include <vtkPointSource.h>
#include <vtkPolyDataMapper.h>
#include <vtkProperty.h>
#include <vtkProperty2D.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkRenderer.h>
#include <vtkSliderRepresentation2D.h>
#include <vtkSliderWidget.h>
#include <vtkSphereSource.h>
#include <vtkStreamTracer.h>
#include <vtkStringFormatter.h>
#include <vtkTextProperty.h>
#include <vtkTubeFilter.h>
#include <vtkUnstructuredGrid.h>
#include <vtkVRMLImporter.h>
#include <vtkXMLUnstructuredGridReader.h>

#include <vtk_cli11.h>
// #include <vtk_fmt.h>
// // clang-format off
// #include VTK_FMT(fmt/format.h)
// // clang-format on

#include <chrono>
#include <thread>

namespace fs = std::filesystem;

namespace {

/**
 * @brief The Slider2DProperties struct.
 *
 * These are the default properties.
 * Instantiate the struct and modify as appropriate.
 *
 * @return The properties.
 */
struct Slider2DProperties
{
  struct _Colors
  {
    // The color of the bar.
    std::string barColor{"White"};
    // The color of the ends of the bar.
    std::string barEndsColor{"White"};
    // The color of the text displaying the value.
    std::string labelColor{"White"};
    // The color of the knob when the mouse is held on it.
    std::string selectedColor{"HotPink"};
    // The color of the knob that slides.
    std::string sliderColor{"White"};
    // The color of the text indicating what the slider controls.
    std::string titleColor{"White"};
  };

  struct _Dimensions
  {
    double endCapLength{0.005};
    double endCapWidth{0.05};
    double labelHeight{0.025};
    double sliderLength{0.01};
    double sliderWidth{0.02};
    double titleHeight{0.03};
    double tubeWidth{0.008};
  };

  struct _Position
  {
    int coordinateSystem = VTK_NORMALIZED_VIEWPORT;
    std::array<double, 2> point1{0.1, 0.1};
    std::array<double, 2> point2{0.9, 0.1};
  };

  struct _Range
  {
    double minimumValue{0.0};
    double maximumValue{1.0};
    double value{0.0};
  };

  struct _Text
  {
    // Font families are: Ariel, Courier and Times
    std::string labelFontFamily{"Arial"};
    bool labelBold{true};
    bool labelItalic{false};
    bool labelShadow{true};
    std::string title{};
    std::string titleFontFamily{"Arial"};
    bool titleBold{true};
    bool titleItalic{false};
    bool titleShadow{true};
  };

  struct _Colors Colors;
  struct _Dimensions Dimensions;
  struct _Position Position;
  struct _Range Range;
  struct _Text Text;
};

/**
 * @brief MakeSlider2DProperties
 *
 * This applies more specific values to the default Slider2DProperties.
 *
 * @return The slider 2D properties.
 */
Slider2DProperties MakeSlider2DProperties();

/**
 * @brief Make2DSliderWidget
 *
 * Make a 2D slider widget.
 *
 * @param properties The 2D slider properties.
 * @param iren The vtkInteractor.
 * @return The slider widget.
 */
vtkNew<vtkSliderWidget> Make2DSliderWidget(Slider2DProperties const& properties,
                                           vtkRenderWindowInteractor* iren);

class SliderCallback : public vtkCallbackCommand
{
public:
  static SliderCallback* New()
  {
    return new SliderCallback();
  }
  virtual void Execute(vtkObject* caller, unsigned long, void*)
  {
    vtkSliderWidget* sliderWidget = reinterpret_cast<vtkSliderWidget*>(caller);
    double value = static_cast<vtkSliderRepresentation2D*>(
                       sliderWidget->GetRepresentation())
                       ->GetValue();
    double center[3];
    this->pointSource->GetCenter(center);
    center[axis] = value;
    this->pointSource->SetCenter(center);
    sphereSource->SetCenter(center);
    pointSource->Modified();
    pointSource->Update();
    std::this_thread::sleep_for(std::chrono::milliseconds(delay));
  }

  SliderCallback() = default;

public:
  unsigned int axis = 0;
  unsigned int delay = 500;
  vtkPointSource* pointSource = nullptr;
  vtkSphereSource* sphereSource = nullptr;
};

} // namespace

int main(int argc, char* argv[])
{
  CLI::App app{"The example illustrates how to combine"
               " a geometric description of a scene"
               " with a fluid flow solution."};

  // Define options
  std::string geometry;
  app.add_option("geometry", geometry,
                 "The path to the data file e.g. kitchen.vtk.")
      ->required()
      ->check(CLI::ExistingFile);
  std::string velocity;
  app.add_option("velocity", velocity,
                 "The path to the velocity vtu file, e.g. fire_ug.vtu.")
      ->required()
      ->check(CLI::ExistingFile);
  unsigned int delay = 100;
  app.add_option("-d,--delay", delay,
                 "The delay in milliseconds, default=100ms.");

  CLI11_PARSE(app, argc, argv);

  vtkNew<vtkNamedColors> colors;
  vtkColor3d isoSurfaceColor = colors->GetColor3d("WhiteSmoke");
  vtkColor3d sphereColor = colors->GetColor3d("HotPink");
  vtkColor3d backgroundColor = colors->GetColor3d("SlateGray");

  vtkNew<vtkRenderer> renderer;
  renderer->UseHiddenLineRemovalOn();
  renderer->SetBackground(backgroundColor.GetData());

  vtkNew<vtkRenderWindow> renderWindow;
  renderWindow->SetSize(640, 512);
  auto appFn = fs::path((app.get_name())).stem().string();
  renderWindow->SetWindowName(appFn.c_str());
  renderWindow->AddRenderer(renderer);

  vtkNew<vtkRenderWindowInteractor> renderWindowInteractor;
  renderWindowInteractor->SetRenderWindow(renderWindow);

  auto is = vtkInteractorStyleSwitch::SafeDownCast(
      renderWindowInteractor->GetInteractorStyle());
  if (is)
  {
    is->SetCurrentStyleToTrackballCamera();
  }

  // Import the VRML Files that define the geometry.
  vtkNew<vtkVRMLImporter> vrmlImport;
  vrmlImport->SetRenderWindow(renderWindow);
  vrmlImport->SetFileName(geometry.c_str());
  vrmlImport->Update();

  // Read the UnstructuredGrid file that defines the solution.
  vtkNew<vtkXMLUnstructuredGridReader> solution;
  solution->SetFileName(velocity.c_str());
  solution->Update();

  std::array<double, 6> bounds;
  solution->GetOutput()->GetBounds(bounds.data());
  // std::array<double,3> center;
  // for (int i=0, idx=0; i < bounds.size();idx++, i += 2)
  // {
  //   center[idx] = (bounds[i+1]-bounds[i])/2.0;
  // }
  std::array<double, 3> center{3.0, 1.6, 1.25};

  // Create an outline.
  vtkNew<vtkGenericOutlineFilter> outline;
  outline->SetInputConnection(solution->GetOutputPort());

  // Create Seeds.
  vtkNew<vtkPointSource> seeds;
  seeds->SetRadius(0.2);
  seeds->SetCenter(center.data());
  // seeds->SetCenter(3.0, 1.6, 1.25);
  seeds->SetNumberOfPoints(50);

  // Create streamlines.
  vtkNew<vtkStreamTracer> streamTracer;
  streamTracer->SetIntegrationDirectionToBoth();
  streamTracer->SetInputConnection(solution->GetOutputPort());
  streamTracer->SetSourceConnection(seeds->GetOutputPort());
  streamTracer->SetMaximumPropagation(50);
  streamTracer->SetInitialIntegrationStep(0.2);
  streamTracer->SetMinimumIntegrationStep(0.01);
  streamTracer->SetIntegratorType(2);
  streamTracer->SetComputeVorticity(1);

  vtkNew<vtkTubeFilter> tubes;
  tubes->SetInputConnection(streamTracer->GetOutputPort());
  tubes->SetNumberOfSides(8);
  tubes->SetRadius(0.02);
  tubes->SetVaryRadius(0);

  vtkNew<vtkPolyDataMapper> mapTubes;
  mapTubes->SetInputConnection(tubes->GetOutputPort());
  mapTubes->SetScalarRange(solution->GetOutput()->GetScalarRange());

  vtkNew<vtkActor> tubesActor;
  tubesActor->SetMapper(mapTubes);

  // Create an Isosurface.
  vtkNew<vtkContourFilter> isoSurface;
  isoSurface->SetValue(0, 500.0);
  isoSurface->SetInputConnection(solution->GetOutputPort());

  vtkNew<vtkPolyDataMapper> isoSurfaceMapper;
  isoSurfaceMapper->SetInputConnection(isoSurface->GetOutputPort());
  isoSurfaceMapper->ScalarVisibilityOff();

  vtkNew<vtkActor> isoSurfaceActor;
  isoSurfaceActor->SetMapper(isoSurfaceMapper);
  isoSurfaceActor->GetProperty()->SetOpacity(.5);
  isoSurfaceActor->GetProperty()->SetDiffuseColor(isoSurfaceColor.GetData());

  vtkNew<vtkSphereSource> sphere;
  sphere->SetCenter(seeds->GetCenter());
  sphere->SetRadius(seeds->GetRadius());
  sphere->SetThetaResolution(20);
  sphere->SetPhiResolution(11);
  vtkNew<vtkPolyDataMapper> sphereMapper;
  sphereMapper->SetInputConnection(sphere->GetOutputPort());

  vtkNew<vtkActor> sphereActor;
  sphereActor->SetMapper(sphereMapper);
  sphereActor->GetProperty()->SetOpacity(1.0);
  sphereActor->GetProperty()->SetSpecular(.4);
  sphereActor->GetProperty()->SetSpecularPower(80);
  sphereActor->GetProperty()->SetDiffuseColor(sphereColor.GetData());

  // Create widgets to manipulate point source center.
  auto sp = MakeSlider2DProperties();
  sp.Position.point1 = {0.1, 0.08};
  sp.Position.point2 = {0.3, 0.08};
  sp.Range.minimumValue = bounds[0];
  sp.Range.maximumValue = bounds[1];
  sp.Range.value = center[0];
  sp.Text.title = "X";
  auto widgetX = Make2DSliderWidget(sp, renderWindowInteractor);
  vtkNew<SliderCallback> cbX;
  cbX->axis = 0;
  cbX->pointSource = seeds;
  cbX->sphereSource = sphere;
  cbX->delay = delay;
  widgetX->AddObserver(vtkCommand::InteractionEvent, cbX);

  sp.Position.point1 = {0.4, 0.08};
  sp.Position.point2 = {0.6, 0.08};
  sp.Range.minimumValue = bounds[2];
  sp.Range.maximumValue = bounds[3];
  sp.Range.value = center[1];
  sp.Text.title = "Y";
  auto widgetY = Make2DSliderWidget(sp, renderWindowInteractor);
  vtkNew<SliderCallback> cbY;
  cbY->axis = 1;
  cbY->pointSource = seeds;
  cbY->sphereSource = sphere;
  cbY->delay = delay;
  widgetY->AddObserver(vtkCommand::InteractionEvent, cbY);

  sp.Position.point1 = {0.7, 0.08};
  sp.Position.point2 = {0.9, 0.08};
  sp.Range.minimumValue = bounds[4];
  sp.Range.maximumValue = bounds[5];
  sp.Range.value = center[2];
  sp.Text.title = "Z";
  auto widgetZ = Make2DSliderWidget(sp, renderWindowInteractor);
  vtkNew<SliderCallback> cbZ;
  cbZ->axis = 2;
  cbZ->pointSource = seeds;
  cbZ->sphereSource = sphere;
  cbZ->delay = delay;
  widgetZ->AddObserver(vtkCommand::InteractionEvent, cbZ);

  renderer->AddActor(tubesActor);
  renderer->AddActor(sphereActor);
  renderer->AddActor(isoSurfaceActor);

  renderWindow->Render();

  renderer->GetActiveCamera()->Azimuth(20.0);
  renderer->GetActiveCamera()->Elevation(10.0);
  renderer->GetActiveCamera()->Dolly(1.25);
  renderer->ResetCameraClippingRange();

  renderWindow->Render();

  renderWindowInteractor->Start();

  return EXIT_SUCCESS;
}

namespace {
Slider2DProperties MakeSlider2DProperties()
{
  auto sp = Slider2DProperties();

  sp.Colors.barColor = "Black";
  sp.Colors.barEndsColor = "Indigo";
  sp.Colors.labelColor = "AliceBlue";
  sp.Colors.selectedColor = "Lime";
  sp.Colors.sliderColor = "BurlyWood";
  sp.Colors.titleColor = "AliceBlue";

  sp.Dimensions.sliderLength = 0.02;
  sp.Dimensions.sliderWidth = 0.05;
  sp.Dimensions.endCapLength = 0.015;
  sp.Dimensions.titleHeight = 0.03;
  sp.Dimensions.labelHeight = 0.025;

  sp.Position.point1 = std::array<double, 2>{0.3, 0.1};
  sp.Position.point2 = std::array<double, 2>{0.7, 0.1};

  sp.Range.minimumValue = 3;
  sp.Range.maximumValue = 20;

  return sp;
}

vtkNew<vtkSliderWidget> Make2DSliderWidget(Slider2DProperties const& properties,
                                           vtkRenderWindowInteractor* iren)
{
  vtkNew<vtkNamedColors> colors;

  vtkNew<vtkSliderRepresentation2D> sliderRep;

  // Set the color properties.
  sliderRep->GetTubeProperty()->SetColor(
      colors->GetColor3d(properties.Colors.barColor).GetData());
  sliderRep->GetCapProperty()->SetColor(
      colors->GetColor3d(properties.Colors.barEndsColor).GetData());
  sliderRep->GetLabelProperty()->SetColor(
      colors->GetColor3d(properties.Colors.labelColor).GetData());
  sliderRep->GetSelectedProperty()->SetColor(
      colors->GetColor3d(properties.Colors.selectedColor).GetData());
  sliderRep->GetSliderProperty()->SetColor(
      colors->GetColor3d(properties.Colors.sliderColor).GetData());
  sliderRep->GetTitleProperty()->SetColor(
      colors->GetColor3d(properties.Colors.titleColor).GetData());

  sliderRep->SetEndCapLength(properties.Dimensions.endCapLength);
  sliderRep->SetEndCapWidth(properties.Dimensions.endCapWidth);
  sliderRep->SetLabelHeight(properties.Dimensions.labelHeight);
  sliderRep->SetSliderLength(properties.Dimensions.sliderLength);
  sliderRep->SetSliderWidth(properties.Dimensions.sliderWidth);
  sliderRep->SetTitleHeight(properties.Dimensions.titleHeight);
  sliderRep->SetTubeWidth(properties.Dimensions.tubeWidth);

  // Set the position.
  sliderRep->GetPoint1Coordinate()->SetCoordinateSystem(
      properties.Position.coordinateSystem);
  sliderRep->GetPoint1Coordinate()->SetValue(properties.Position.point1.data());
  sliderRep->GetPoint2Coordinate()->SetCoordinateSystem(
      properties.Position.coordinateSystem);
  sliderRep->GetPoint2Coordinate()->SetValue(properties.Position.point2.data());

  // Set the range.
  sliderRep->SetMinimumValue(properties.Range.minimumValue);
  sliderRep->SetMaximumValue(properties.Range.maximumValue);
  sliderRep->SetValue(properties.Range.value);

  // Set label and title fonts properties.
  // Also set the title.
  std::string labelFontFamily = properties.Text.labelFontFamily;
  if (labelFontFamily == "Courier")
  {
    sliderRep->GetLabelProperty()->SetFontFamilyToCourier();
  }
  else if (labelFontFamily == "Times")
  {
    sliderRep->GetLabelProperty()->SetFontFamilyToTimes();
  }
  else
  {
    sliderRep->GetLabelProperty()->SetFontFamilyToArial();
  }
  sliderRep->GetLabelProperty()->SetBold(properties.Text.labelBold);
  sliderRep->GetLabelProperty()->SetItalic(properties.Text.labelItalic);
  sliderRep->GetLabelProperty()->SetShadow(properties.Text.labelShadow);
  sliderRep->SetTitleText(properties.Text.title.c_str());
  std::string titleFontFamily = properties.Text.titleFontFamily;
  if (titleFontFamily == "Courier")
  {
    sliderRep->GetLabelProperty()->SetFontFamilyToCourier();
  }
  else if (titleFontFamily == "Times")
  {
    sliderRep->GetLabelProperty()->SetFontFamilyToTimes();
  }
  else
  {
    sliderRep->GetLabelProperty()->SetFontFamilyToArial();
  }
  sliderRep->GetTitleProperty()->SetBold(properties.Text.titleBold);
  sliderRep->GetTitleProperty()->SetItalic(properties.Text.titleItalic);
  sliderRep->GetTitleProperty()->SetShadow(properties.Text.titleShadow);

  vtkNew<vtkSliderWidget> widget;
  widget->SetInteractor(iren);
  widget->SetRepresentation(sliderRep);
  widget->EnabledOn();
  widget->SetAnimationModeToAnimate();

  return widget;
}

} // namespace
