// These includes are necessary for WhatModulesVTK.py
#include <vtkActor.h>
#include <vtkAxes.h>
#include <vtkBYUReader.h>
#include <vtkCallbackCommand.h>
#include <vtkCamera.h>
#include <vtkNamedColors.h>
#include <vtkPNGWriter.h>
#include <vtkPolyDataMapper.h>
#include <vtkProperty.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkRenderer.h>
#include <vtkSmartPointer.h>
#include <vtkTransform.h>
#include <vtkVersionMacros.h>
#include <vtkWindowToImageFilter.h>

// The command line parameters are: cow.g 2
#include "WalkCow.cxx"
