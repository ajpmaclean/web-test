#include <vtkCamera.h>
#include <vtkColorTransferFunction.h>
#include <vtkContourValues.h>
#include <vtkInteractorStyleTrackballCamera.h>
#include <vtkMetaImageReader.h>
#include <vtkNamedColors.h>
#include <vtkNew.h>
#include <vtkOpenGLGPUVolumeRayCastMapper.h>
#include <vtkPiecewiseFunction.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkRenderer.h>
#include <vtkVolume.h>
#include <vtkVolumeProperty.h>

#include <vtk_cli11.h>
#include <vtk_fmt.h>
// clang-format off
#include VTK_FMT(fmt/format.h)
// clang-format on

#include <filesystem>

namespace fs = std::filesystem;

int main(int argc, char* argv[])
{
  CLI::App app{"Use volume rendering to produce an iso-surface-like image."};

  // Define options
  std::string fileName;
  app.add_option("fileName", fileName,
                 "The path to the data file e.g. FullHead.mhd.")
      ->required()
      ->check(CLI::ExistingFile);
  double iso1{500};
  app.add_option("iso1", iso1, "The first iso-contour.");
  double iso2{1150};
  app.add_option("iso2", iso2, "The second iso-contour.");

  CLI11_PARSE(app, argc, argv);

  vtkNew<vtkMetaImageReader> reader;
  reader->SetFileName(fileName.c_str());

  vtkNew<vtkNamedColors> colors;

  vtkNew<vtkOpenGLGPUVolumeRayCastMapper> mapper;
  mapper->SetInputConnection(reader->GetOutputPort());
  mapper->AutoAdjustSampleDistancesOff();
  mapper->SetSampleDistance(0.5);
  mapper->SetBlendModeToIsoSurface();

  if (argc > 3)
  {
    iso1 = atof(argv[2]);
    iso2 = atof(argv[3]);
  }
  vtkNew<vtkColorTransferFunction> colorTransferFunction;
  colorTransferFunction->RemoveAllPoints();
  colorTransferFunction->AddRGBPoint(iso2,
                                     colors->GetColor3d("ivory").GetData()[0],
                                     colors->GetColor3d("ivory").GetData()[1],
                                     colors->GetColor3d("ivory").GetData()[2]);
  colorTransferFunction->AddRGBPoint(iso1,
                                     colors->GetColor3d("flesh").GetData()[0],
                                     colors->GetColor3d("flesh").GetData()[1],
                                     colors->GetColor3d("flesh").GetData()[2]);

  vtkNew<vtkPiecewiseFunction> scalarOpacity;
  scalarOpacity->AddPoint(iso1, 0.3);
  scalarOpacity->AddPoint(iso2, 0.6);

  vtkNew<vtkVolumeProperty> volumeProperty;
  volumeProperty->ShadeOn();
  volumeProperty->SetInterpolationTypeToLinear();
  volumeProperty->SetColor(colorTransferFunction);
  volumeProperty->SetScalarOpacity(scalarOpacity);

  vtkNew<vtkVolume> volume;
  volume->SetMapper(mapper);
  volume->SetProperty(volumeProperty);

  vtkNew<vtkRenderer> renderer;
  renderer->AddVolume(volume);
  renderer->SetBackground(colors->GetColor3d("cornflower").GetData());
  renderer->ResetCamera();

  vtkNew<vtkRenderWindow> renderWindow;
  auto appFn = fs::path((app.get_name())).stem().string();
  renderWindow->SetSize(800, 600);
  renderWindow->SetWindowName(appFn.c_str());
  renderWindow->AddRenderer(renderer);
  renderWindow->SetWindowName("RayCastIsosurface");

  vtkNew<vtkInteractorStyleTrackballCamera> style;

  vtkNew<vtkRenderWindowInteractor> interactor;
  interactor->SetRenderWindow(renderWindow);
  interactor->SetInteractorStyle(style);

  // Add some contour values to draw iso surfaces
  volumeProperty->GetIsoSurfaceValues()->SetValue(0, iso1);
  volumeProperty->GetIsoSurfaceValues()->SetValue(1, iso2);

  // Generate a good view
  vtkNew<vtkCamera> aCamera;
  aCamera->SetViewUp(0, 0, 1);
  aCamera->SetPosition(0, -1, 0);
  aCamera->SetFocalPoint(0, 0, 0);

  renderer->SetActiveCamera(aCamera);
  renderer->ResetCamera();

  aCamera->Azimuth(30.0);
  aCamera->Elevation(30.0);
  aCamera->Dolly(1.5);
  renderer->ResetCameraClippingRange();

  renderWindow->Render();

  interactor->Start();

  return EXIT_SUCCESS;
}
