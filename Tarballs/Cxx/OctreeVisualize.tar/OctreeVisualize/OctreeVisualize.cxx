#include <vtkActor.h>
#include <vtkCommand.h>
#include <vtkInteractorStyleTrackballCamera.h>
#include <vtkNamedColors.h>
#include <vtkNew.h>
#include <vtkOctreePointLocator.h>
#include <vtkPolyData.h>
#include <vtkPolyDataMapper.h>
#include <vtkProperty.h>
#include <vtkProperty2D.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkRenderer.h>
#include <vtkSliderRepresentation2D.h>
#include <vtkSliderWidget.h>
#include <vtkSphereSource.h>
#include <vtkTextProperty.h>

namespace {

/**
 * @brief The Slider2DProperties struct.
 *
 * These are the default properties.
 * Instantiate the struct and modify as appropriate.
 *
 * @return The properties.
 */
struct Slider2DProperties
{
  struct _Colors
  {
    // The color of the text indicating what the slider controls.
    std::string titleColor{"White"};
    // The color of the text displaying the value.
    std::string labelColor{"White"};
    // The color of the knob that slides.
    std::string sliderColor{"White"};
    // The color of the bar.
    std::string barColor{"White"};
    // The color of the ends of the bar.
    std::string barEndsColor{"White"};
    // The color of the knob when the mouse is held on it.
    std::string selectedColor{"HotPink"};
  };

  struct _Dimensions
  {
    double tubeWidth{0.008};
    double sliderLength{0.01};
    double sliderWidth{0.02};
    double endCapLength{0.005};
    double endCapWidth{0.05};
    double titleHeight{0.03};
    double labelHeight{0.025};
  };

  struct _Position
  {
    int coordinateSystem = VTK_NORMALIZED_VIEWPORT;
    std::array<double, 2> point1{0.1, 0.1};
    std::array<double, 2> point2{0.9, 0.1};
  };

  struct _Range
  {
    double minimumValue{0.0};
    double maximumValue{1.0};
    double value{0.0};
  };

  struct _Text
  {
    // Font families are: Ariel, Courier and Times
    std::string title{};
    std::string titleFontFamily{"Arial"};
    bool titleBold{true};
    bool titleItalic{false};
    bool titleShadow{true};
    std::string labelFontFamily{"Arial"};
    bool labelBold{true};
    bool labelItalic{false};
    bool labelShadow{true};
  };

  struct _Colors Colors;
  struct _Dimensions Dimensions;
  struct _Position Position;
  struct _Range Range;
  struct _Text Text;
};

/**
 * @brief MakeSlider2DProperties
 *
 * This applies more specific values to the default Slider2DProperties.
 *
 * @return The slider 2D properties.
 */
Slider2DProperties MakeSlider2DProperties();

/**
 * @brief Make2DSliderWidget
 *
 * Make a 2D slider widget.
 *
 * @param properties The 2D slider properties.
 * @param iren The vtkInteractor.
 * @return The slider widget.
 */
vtkNew<vtkSliderWidget> Make2DSliderWidget(Slider2DProperties const& properties,
                                           vtkRenderWindowInteractor* iren);

class vtkSliderCallback : public vtkCommand
{
public:
  static vtkSliderCallback* New()
  {
    return new vtkSliderCallback;
  }

  vtkSliderCallback() : octree(0), polydata(0)
  {
  }

  virtual void Execute(vtkObject* caller, unsigned long, void*)
  {
    vtkSliderWidget* sliderWidget = reinterpret_cast<vtkSliderWidget*>(caller);
    auto level = static_cast<int>(vtkMath::Round(
        static_cast<vtkSliderRepresentation*>(sliderWidget->GetRepresentation())
            ->GetValue()));
    this->octree->GenerateRepresentation(level, this->polydata);
    sliderWidget->GetSliderRepresentation()->SetValue(level);
  }

  vtkOctreePointLocator* octree;
  vtkPolyData* polydata;
};
} // namespace

int main(int, char*[])
{
  vtkNew<vtkNamedColors> colors;

  // Create a point cloud.
  vtkNew<vtkSphereSource> pointSource;
  pointSource->SetPhiResolution(50);
  pointSource->SetThetaResolution(50);
  pointSource->Update();
  vtkNew<vtkPolyDataMapper> pointsMapper;
  pointsMapper->SetInputConnection(pointSource->GetOutputPort());
  vtkNew<vtkActor> pointsActor;
  pointsActor->SetMapper(pointsMapper);
  pointsActor->GetProperty()->SetRepresentationToPoints();
  pointsActor->GetProperty()->SetInterpolationToFlat();
  pointsActor->GetProperty()->SetColor(colors->GetColor4d("Yellow").GetData());

  // Create the tree.
  vtkNew<vtkOctreePointLocator> octree;
  octree->SetMaximumPointsPerRegion(5);
  octree->SetDataSet(pointSource->GetOutput());
  octree->BuildLocator();

  vtkNew<vtkPolyData> polydata;
  octree->GenerateRepresentation(0, polydata);

  vtkNew<vtkPolyDataMapper> octreeMapper;
  octreeMapper->SetInputData(polydata);

  vtkNew<vtkActor> octreeActor;
  octreeActor->SetMapper(octreeMapper);
  octreeActor->GetProperty()->SetInterpolationToFlat();
  octreeActor->GetProperty()->SetRepresentationToWireframe();
  octreeActor->GetProperty()->SetColor(
      colors->GetColor4d("SpringGreen").GetData());

  // A renderer and render window.
  vtkNew<vtkRenderer> ren;
  ren->SetBackground(colors->GetColor3d("MidnightBlue").GetData());
  ren->UseHiddenLineRemovalOn();
  vtkNew<vtkRenderWindow> renWin;
  renWin->SetWindowName("OctreeVisualize");
  renWin->SetSize(600, 600);
  renWin->AddRenderer(ren);

  // An interactor
  vtkNew<vtkInteractorStyleTrackballCamera> style;
  vtkNew<vtkRenderWindowInteractor> iren;
  iren->SetRenderWindow(renWin);
  iren->SetInteractorStyle(style);

  // Add the actors to the scene
  ren->AddActor(pointsActor);
  ren->AddActor(octreeActor);

  // Render an image (lights and cameras are created automatically)
  renWin->Render();

  vtkNew<vtkSliderRepresentation2D> sliderRep;
  sliderRep->SetMinimumValue(0);
  sliderRep->SetMaximumValue(octree->GetLevel());
  sliderRep->SetValue(0);
  sliderRep->SetTitleText("Level");
  sliderRep->GetPoint1Coordinate()->SetCoordinateSystemToNormalizedDisplay();
  sliderRep->GetPoint1Coordinate()->SetValue(.2, .2);
  sliderRep->GetPoint2Coordinate()->SetCoordinateSystemToNormalizedDisplay();
  sliderRep->GetPoint2Coordinate()->SetValue(.8, .2);
  sliderRep->SetSliderLength(0.075);
  sliderRep->SetSliderWidth(0.05);
  sliderRep->SetEndCapLength(0.05);
  sliderRep->GetTitleProperty()->SetColor(
      colors->GetColor3d("Beige").GetData());
  sliderRep->GetCapProperty()->SetColor(
      colors->GetColor3d("MistyRose").GetData());
  sliderRep->GetSliderProperty()->SetColor(
      colors->GetColor3d("LightBlue").GetData());
  sliderRep->GetSelectedProperty()->SetColor(
      colors->GetColor3d("Violet").GetData());

  auto sp = MakeSlider2DProperties();
  sp.Dimensions.titleHeight = 0.03;
  sp.Dimensions.labelHeight = 0.025;
  sp.Range.minimumValue = 0;
  sp.Range.maximumValue = octree->GetLevel();
  sp.Range.value = 2;

  sp.Text.title = "Level";

  octree->GenerateRepresentation(sp.Range.value, polydata);

  auto sliderWidget = Make2DSliderWidget(sp, iren);

  vtkNew<vtkSliderCallback> callback;
  callback->octree = octree;
  callback->polydata = polydata;
  callback->Execute(sliderWidget, 0, 0);

  sliderWidget->AddObserver(vtkCommand::InteractionEvent, callback);

  renWin->Render();
  iren->Initialize();
  iren->Start();

  return EXIT_SUCCESS;
}

namespace {

Slider2DProperties MakeSlider2DProperties()
{
  auto sp = Slider2DProperties();

  // Set color properties:
  // Change the color of the knob that slides.
  sp.Colors.sliderColor = "Green";
  // Change the color of the text indicating what the slider controls.
  sp.Colors.titleColor = "AliceBlue";
  // Change the color of the text displaying the value.
  sp.Colors.labelColor = "AliceBlue";
  // Change the color of the knob when the mouse is held on it.
  sp.Colors.selectedColor = "DeepPink";
  // Change the color of the bar.
  sp.Colors.barColor = "MistyRose";
  // Change the color of the ends of the bar.
  sp.Colors.barEndsColor = "Yellow";
  sp.Dimensions.sliderLength = 0.05;
  sp.Dimensions.sliderWidth = 0.025;
  sp.Dimensions.endCapLength = 0.02;
  sp.Dimensions.titleHeight = 0.045;
  sp.Dimensions.labelHeight = 0.035;
  sp.Position.point1 = std::array<double, 2>{0.3, 0.1};
  sp.Position.point2 = std::array<double, 2>{0.7, 0.1};

  return sp;
}

vtkNew<vtkSliderWidget> Make2DSliderWidget(Slider2DProperties const& properties,
                                           vtkRenderWindowInteractor* iren)
{
  vtkNew<vtkNamedColors> colors;

  vtkNew<vtkSliderRepresentation2D> sliderRep;

  sliderRep->SetMinimumValue(properties.Range.minimumValue);
  sliderRep->SetMaximumValue(properties.Range.maximumValue);
  sliderRep->SetValue(properties.Range.value);
  sliderRep->SetTitleText(properties.Text.title.c_str());
  sliderRep->SetTubeWidth(properties.Dimensions.tubeWidth);
  sliderRep->SetSliderLength(properties.Dimensions.sliderLength);
  sliderRep->SetSliderWidth(properties.Dimensions.sliderWidth);
  sliderRep->SetEndCapLength(properties.Dimensions.endCapLength);
  sliderRep->SetEndCapWidth(properties.Dimensions.endCapWidth);
  sliderRep->SetTitleHeight(properties.Dimensions.titleHeight);
  sliderRep->SetLabelHeight(properties.Dimensions.labelHeight);

  // Set the color properties.
  sliderRep->GetTitleProperty()->SetColor(
      colors->GetColor3d(properties.Colors.titleColor).GetData());
  sliderRep->GetLabelProperty()->SetColor(
      colors->GetColor3d(properties.Colors.labelColor).GetData());
  sliderRep->GetTubeProperty()->SetColor(
      colors->GetColor3d(properties.Colors.barColor).GetData());
  sliderRep->GetCapProperty()->SetColor(
      colors->GetColor3d(properties.Colors.barEndsColor).GetData());
  sliderRep->GetSliderProperty()->SetColor(
      colors->GetColor3d(properties.Colors.sliderColor).GetData());
  sliderRep->GetSelectedProperty()->SetColor(
      colors->GetColor3d(properties.Colors.selectedColor).GetData());

  // Set the position.
  sliderRep->GetPoint1Coordinate()->SetCoordinateSystem(
      properties.Position.coordinateSystem);
  sliderRep->GetPoint1Coordinate()->SetValue(properties.Position.point1.data());
  sliderRep->GetPoint2Coordinate()->SetCoordinateSystem(
      properties.Position.coordinateSystem);
  sliderRep->GetPoint2Coordinate()->SetValue(properties.Position.point2.data());

  std::string titleFontFamily = properties.Text.titleFontFamily;
  if (titleFontFamily == "Courier")
  {
    sliderRep->GetLabelProperty()->SetFontFamilyToCourier();
  }
  else if (titleFontFamily == "Times")
  {
    sliderRep->GetLabelProperty()->SetFontFamilyToTimes();
  }
  else
  {
    sliderRep->GetLabelProperty()->SetFontFamilyToArial();
  }
  sliderRep->GetTitleProperty()->SetBold(properties.Text.titleBold);
  sliderRep->GetTitleProperty()->SetItalic(properties.Text.titleItalic);
  sliderRep->GetTitleProperty()->SetShadow(properties.Text.titleShadow);
  std::string labelFontFamily = properties.Text.labelFontFamily;
  if (labelFontFamily == "Courier")
  {
    sliderRep->GetLabelProperty()->SetFontFamilyToCourier();
  }
  else if (labelFontFamily == "Times")
  {
    sliderRep->GetLabelProperty()->SetFontFamilyToTimes();
  }
  else
  {
    sliderRep->GetLabelProperty()->SetFontFamilyToArial();
  }
  sliderRep->GetLabelProperty()->SetBold(properties.Text.labelBold);
  sliderRep->GetLabelProperty()->SetItalic(properties.Text.labelItalic);
  sliderRep->GetLabelProperty()->SetShadow(properties.Text.labelShadow);

  vtkNew<vtkSliderWidget> widget;
  widget->SetInteractor(iren);
  widget->SetRepresentation(sliderRep);
  widget->EnabledOn();
  widget->SetAnimationModeToAnimate();

  return widget;
}

} // namespace
