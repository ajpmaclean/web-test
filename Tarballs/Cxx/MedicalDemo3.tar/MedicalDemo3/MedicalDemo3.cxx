// Derived from VTK/Examples/Cxx/Medical3.cxx
// This example reads a volume dataset, extracts two isosurfaces that
// represent the skin and bone, creates three orthogonal planes
// (sagittal, axial, coronal), and displays them.
//
#include <vtkActor.h>
#include <vtkCamera.h>
#include <vtkCameraOrientationRepresentation.h>
#include <vtkCameraOrientationWidget.h>
#include <vtkFlyingEdges3D.h>
#include <vtkImageActor.h>
#include <vtkImageMapToColors.h>
#include <vtkImageMapper3D.h>
#include <vtkImageResliceMapper.h>
#include <vtkInteractorStyleSwitch.h>
#include <vtkLookupTable.h>
#include <vtkMetaImageReader.h>
#include <vtkNamedColors.h>
#include <vtkNew.h>
#include <vtkOutlineFilter.h>
#include <vtkPlane.h>
#include <vtkPolyDataMapper.h>
#include <vtkProperty.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkRenderer.h>
#include <vtkStripper.h>

#include <vtk_cli11.h>
#include <vtk_fmt.h>
// clang-format off
#include VTK_FMT(fmt/format.h)
// clang-format on

#include <array>

namespace fs = std::filesystem;

namespace {

typedef std::map<std::string, std::string> TAxisParams;
typedef std::map<std::string, TAxisParams> TAxesParams;

/**
 * @brief Define the axes labels.
 *
 * @return The axes labels.
 */
TAxesParams DefineAxesLabels();

/**
 * @brief Define the axes colors.
 *
 * @return The axes colors.
 */
TAxesParams DefineAxesColors();

/**
 * @brief Gather the defined axes labels and colors into a map.
 *
 * @return The map of axes labels and colors.
 */
std::map<std::string, std::pair<TAxisParams, TAxisParams>> GetAxesParams();

/**
 * @brief Make a camera orientation widget for a given renderer.
 *
 * position has these values 0: LowerLeft, 1: UpperLeft, 2: LowerRight, 3:
 * UpperRight
 *
 * @param ren The renderer.
 * @param alc The key specifying the desired labels and colors for the axes.
 * @param colors A reference to the vtkNamedColors object.
 * @param position Move the camera orientation widget to upper left.
 *
 * @return The camera orientation widget.
 */
vtkNew<vtkCameraOrientationWidget>
MakeCameraOrientationWidget(vtkRenderer* ren, std::string alcKey = "xyz",
                            int const& position = 3);
} // namespace

int main(int argc, char* argv[])
{
  CLI::App app{"A Composite image of three planes and translucent skin "
               "extracted from a CT dataset of the head."};

  // Define options
  std::string fileName;
  app.add_option("fileName", fileName,
                 "The path to the data file e.g. FullHead.mhd.")
      ->required()
      ->check(CLI::ExistingFile);

  bool flyingEdges = true;
  app.add_flag("-m{false},!-n", flyingEdges,
               "Use flying edges by default, marching cubes if set.");

  CLI11_PARSE(app, argc, argv);

  if (flyingEdges)
  {
#define USE_FLYING_EDGES
  }

  vtkNew<vtkNamedColors> colors;

  std::array<unsigned char, 4> skinColor{{240, 184, 160, 255}};
  colors->SetColor("SkinColor", skinColor.data());
  std::array<unsigned char, 4> bkg{{51, 77, 102, 255}};
  colors->SetColor("BkgColor", bkg.data());

  // Create the renderer, the render window, and the interactor. The
  // renderer draws into the render window, the interactor enables
  // mouse- and keyboard-based interaction with the data within the
  // render window.
  //
  vtkNew<vtkRenderer> ren;
  vtkNew<vtkRenderWindow> renWin;
  // Set a background color for the renderer and set the size of the
  // render window (expressed in pixels).
  ren->SetBackground(colors->GetColor3d("BkgColor").GetData());
  renWin->SetSize(640, 480);
  auto appFn = fs::path((app.get_name())).stem().string();
  renWin->SetWindowName(appFn.c_str());
  renWin->AddRenderer(ren);

  vtkNew<vtkRenderWindowInteractor> iren;
  iren->SetRenderWindow(renWin);
  auto is = vtkInteractorStyleSwitch::SafeDownCast(iren->GetInteractorStyle());
  if (is)
  {
    is->SetCurrentStyleToTrackballCamera();
  }

  // The following reader is used to read a series of 2D slices (images)
  // that compose the volume. The slice dimensions are set, and the
  // pixel spacing. The data Endianness must also be specified. The
  // reader uses the FilePrefix in combination with the slice number to
  // construct filenames using the format FilePrefix.%d. (In this case
  // the FilePrefix is the root name of the file: quarter.)
  vtkNew<vtkMetaImageReader> reader;
  reader->SetFileName(argv[1]);
  reader->Update();

  // An isosurface, or contour value of 500 is known to correspond to
  // the skin of the patient.
  // The triangle stripper is used to create triangle
  // strips from the isosurface; these render much faster on may
  // systems.
#ifdef USE_FLYING_EDGES
  vtkNew<vtkFlyingEdges3D> skinExtractor;
#else
  vtkNew<vtkMarchingCubes> skinExtractor;
#endif
  skinExtractor->SetInputConnection(reader->GetOutputPort());
  skinExtractor->SetValue(0, 500);
  skinExtractor->Update();

  vtkNew<vtkStripper> skinStripper;
  skinStripper->SetInputConnection(skinExtractor->GetOutputPort());
  skinStripper->Update();

  vtkNew<vtkPolyDataMapper> skinMapper;
  skinMapper->SetInputConnection(skinStripper->GetOutputPort());
  skinMapper->ScalarVisibilityOff();

  auto bounds = skinMapper->GetBounds();
  std::array<double, 3> centroid{0.0, 0.0, 0.0};
  for (auto i = 0; i < 6; i += 2)
  {
    auto x = bounds[i];
    auto y = bounds[i + 1];
    centroid[(i + 1) / 2] = x + (y - x) / 2.0;
  }

  vtkNew<vtkActor> skin;
  skin->SetMapper(skinMapper);
  skin->GetProperty()->SetDiffuseColor(
      colors->GetColor3d("SkinColor").GetData());
  skin->GetProperty()->SetSpecular(0.3);
  skin->GetProperty()->SetSpecularPower(20);

  // An isosurface, or contour value of 1150 is known to correspond to
  // the bone of the patient.
  // The triangle stripper is used to create triangle
  // strips from the isosurface; these render much faster on may
  // systems.
#ifdef USE_FLYING_EDGES
  vtkNew<vtkFlyingEdges3D> boneExtractor;
#else
  vtkNew<vtkMarchingCubes> boneExtractor;
#endif
  boneExtractor->SetInputConnection(reader->GetOutputPort());
  boneExtractor->SetValue(0, 1150);

  vtkNew<vtkStripper> boneStripper;
  boneStripper->SetInputConnection(boneExtractor->GetOutputPort());

  vtkNew<vtkPolyDataMapper> boneMapper;
  boneMapper->SetInputConnection(boneStripper->GetOutputPort());
  boneMapper->ScalarVisibilityOff();

  vtkNew<vtkActor> bone;
  bone->SetMapper(boneMapper);
  bone->GetProperty()->SetDiffuseColor(colors->GetColor3d("Ivory").GetData());

  // An outline provides context around the data.
  //
  vtkNew<vtkOutlineFilter> outlineData;
  outlineData->SetInputConnection(reader->GetOutputPort());
  outlineData->Update();

  vtkNew<vtkPolyDataMapper> outlineMapper;
  outlineMapper->SetInputConnection(outlineData->GetOutputPort());

  vtkNew<vtkActor> outline;
  outline->SetMapper(outlineMapper);
  outline->GetProperty()->SetColor(colors->GetColor3d("Black").GetData());

  // Now we are creating three orthogonal planes passing through the
  // volume. Each plane uses a different texture map and therefore has
  // different coloration.

  // Start by creating a black/white lookup table.
  vtkNew<vtkLookupTable> bwLut;
  bwLut->SetTableRange(0, 2000);
  bwLut->SetSaturationRange(0, 0);
  bwLut->SetHueRange(0, 0);
  bwLut->SetValueRange(0, 1);
  bwLut->Build(); // effective built

  // Now create a lookup table that consists of the full hue circle
  // (from HSV).
  vtkNew<vtkLookupTable> hueLut;
  hueLut->SetTableRange(0, 2000);
  hueLut->SetHueRange(0, 1);
  hueLut->SetSaturationRange(1, 1);
  hueLut->SetValueRange(1, 1);
  hueLut->Build(); // effective built

  // Finally, create a lookup table with a single hue but having a range
  // in the saturation of the hue.
  vtkNew<vtkLookupTable> satLut;
  satLut->SetTableRange(0, 2000);
  satLut->SetHueRange(0.6, 0.6);
  satLut->SetSaturationRange(0, 1);
  satLut->SetValueRange(1, 1);
  satLut->Build(); // effective built

  // Use vtkImageMapToColors to map the scalar components of an input image
  // through a lookup table to produce an RGBA or RGB output imag
  // Then create a slice planes through a 3D image volume using
  // vtkImageSlice, combining it with a vtkImageResliceMapper and a vtkPlane.

  // Create the first (saggital) plane of the three planes.
  vtkNew<vtkImageMapToColors> sagittalColors;
  sagittalColors->SetInputConnection(reader->GetOutputPort());
  sagittalColors->SetLookupTable(bwLut);
  sagittalColors->Update();

  vtkNew<vtkPlane> sp;
  sp->SetOrigin(centroid.data());
  sp->SetNormal(1, 0, 0);

  vtkNew<vtkImageResliceMapper> sagittalMapper;
  sagittalMapper->SetInputConnection(sagittalColors->GetOutputPort());
  sagittalMapper->SetSlicePlane(sp); // Apply the custom slice plane

  vtkNew<vtkImageSlice> sagittalSlice;
  sagittalSlice->SetMapper(sagittalMapper);

  // Create the second (axial) plane of the three planes. We use the
  // same approach as before except that the extent differs.
  vtkNew<vtkImageMapToColors> axialColors;
  axialColors->SetInputConnection(reader->GetOutputPort());
  axialColors->SetLookupTable(hueLut);
  axialColors->Update();

  vtkNew<vtkPlane> ap;
  ap->SetOrigin(centroid.data());
  ap->SetNormal(0, 0, 1);

  vtkNew<vtkImageResliceMapper> axialMapper;
  axialMapper->SetInputConnection(axialColors->GetOutputPort());
  axialMapper->SetSlicePlane(ap); // Apply the custom slice plane

  vtkNew<vtkImageSlice> axialSlice;
  axialSlice->SetMapper(axialMapper);

  // Create the third (coronal) plane of the three planes. We use
  // the same approach as before except that the extent differs.
  vtkNew<vtkImageMapToColors> coronalColors;
  coronalColors->SetInputConnection(reader->GetOutputPort());
  coronalColors->SetLookupTable(satLut);
  coronalColors->Update();

  vtkNew<vtkPlane> cp;
  cp->SetOrigin(centroid.data());
  cp->SetNormal(0, 1, 0);

  vtkNew<vtkImageResliceMapper> coronalMapper;
  coronalMapper->SetInputConnection(coronalColors->GetOutputPort());
  coronalMapper->SetSlicePlane(cp); // Apply the custom slice plane

  vtkNew<vtkImageSlice> coronalSlice;
  coronalSlice->SetMapper(coronalMapper);

  // Turn off bone for this example.
  bone->VisibilityOff();

  // Set skin to semi-transparent.
  skin->GetProperty()->SetOpacity(0.5);

  // It is convenient to create an initial view of the data. The
  // FocalPoint and Position form a vector direction. Later on
  // (ResetCamera() method) this vector is used to position the camera
  // to look at the data in this direction.
  vtkNew<vtkCamera> camera;
  camera->SetViewUp(0, 0, 1);
  camera->SetPosition(0, -1, 0);
  camera->SetFocalPoint(0, 0, 0);
  camera->ComputeViewPlaneNormal();
  camera->Azimuth(30.0);
  camera->Elevation(30.0);

  // Actors are added to the renderer.
  ren->AddActor(outline);
  ren->AddActor(sagittalSlice);
  ren->AddActor(axialSlice);
  ren->AddActor(coronalSlice);
  ren->AddActor(skin);
  ren->AddActor(bone);
  // An initial camera view is created. The Dolly() method moves
  // the camera towards the FocalPoint, thereby enlarging the image.
  ren->SetActiveCamera(camera);
  ren->ResetCamera();
  camera->Dolly(1.5);

  // Calling Render() directly on a vtkRenderer is strictly forbidden.
  // Only calling Render() on the vtkRenderWindow is a valid call.
  // renWin->Render();

  // Note that when camera movement occurs (as it does in the Dolly()
  // method), the clipping planes often need adjusting. Clipping planes
  // consist of two planes: near and far along the view direction. The
  // near plane clips out objects in front of the plane; the far plane
  // clips out objects behind the plane. This way only what is drawn
  // between the planes is actually rendered.
  ren->ResetCameraClippingRange();

  // Important: The interactor must be set prior to enabling the widget.
  auto cow = MakeCameraOrientationWidget(ren);
  cow->On();

  auto category = "lrpasi";
  auto cow1 = MakeCameraOrientationWidget(ren, category, 1);
  cow1->On();

  // Interact with the data.
  iren->Initialize();
  iren->Start();

  return EXIT_SUCCESS;
}

namespace {
TAxesParams DefineAxesLabels()
{
  // clang-format off
  return {
          // Labels are: Anterior, Posterior, Dorsal, Ventral, Left, Right
          {"apdvlr", {{"+X", "A"},{"-X", "P"},{"+Y", "D"},{"-Y", "V"},{"+Z", "L"},{"-Z", "R"}}},
          {"apdvrl",{{"+X", "A"},{"-X", "P"},{"+Y", "D"},{"-Y", "V"},{"+Z", "R"},{"-Z", "L"}}},
          {"aprlvd",{{"+X", "A"},{"-X", "P"},{"+Y", "R"},{"-Y", "L"},{"+Z", "V"},{"-Z", "D"}}},
          {"padvlr", {{"+X", "P"},{"-X", "A"},{"+Y", "D"},{"-Y", "V"},{"+Z", "L"},{"-Z", "R"}}},
          // Labels are: Left, Right, Superior, Inferior, Anterior, Posterior
          {"lrsiap",{{"+X", "L"},{"-X", "R"},{"+Y", "S"},{"-Y", "I"},{"+Z", "A"},{"-Z", "P"}}},
          {"lrpasi",{{"+X", "L"},{"-X", "R"},{"+Y", "P"},{"-Y", "A"},{"+Z", "S"},{"-Z", "I"}}},
          {"rlpais",{{"+X", "R"},{"-X", "L"},{"+Y", "P"},{"-Y", "A"},{"+Z", "I"},{"-Z", "S"}}},
          // Default labels.
          {"xyz", {}},
          };
  // clang-format on
}

TAxesParams DefineAxesColors()
{
  // clang-format off
  TAxisParams color1{{"+X", "IndianRed"},{"-X", "FireBrick"},
                     {"+Y", "LimeGreen"},{"-Y", "DarkGreen"},
                     {"+Z", "Blue"}, {"-Z", "SteelBlue"}};
  return {
          {"apdvlr",color1},
          {"apdvrl",color1},
          {"aprlvd",color1},
          {"padvlr",color1},
          {"lrsiap",color1},
          // Default colors.
          {"lrpasi", {}},
          {"rlpais", {}},
          {"xyz", {}},
          };
  // clang-format on
}

std::map<std::string, std::pair<TAxisParams, TAxisParams>> GetAxesParams()
{
  vtkNew<vtkNamedColors> colors;

  // The keys must be the same.
  auto axesLabels = DefineAxesLabels();
  auto axesColors = DefineAxesColors();
  // Get the keys.
  std::set<std::string> labelKeys;
  for (auto&& label : axesLabels)
  {
    labelKeys.insert(label.first);
  }
  std::set<std::string> colorKeys;
  for (auto&& label : axesLabels)
  {
    colorKeys.insert(label.first);
  }
  std::vector<std::string> commonKeys;
  std::set_intersection(labelKeys.begin(), labelKeys.end(), colorKeys.begin(),
                        colorKeys.end(), std::back_inserter(commonKeys));
  std::map<std::string, std::pair<TAxisParams, TAxisParams>> alc;
  for (auto&& k : commonKeys)
  {
    alc[k] = std::pair<TAxisParams, TAxisParams>{axesLabels[k], axesColors[k]};
  }

  return alc;
};

vtkNew<vtkCameraOrientationWidget>
MakeCameraOrientationWidget(vtkRenderer* ren, std::string alcKey,
                            int const& position)
{

  vtkNew<vtkCameraOrientationWidget> cow;
  cow->SetParentRenderer(ren);
  cow->EnabledOn();

  auto axesParameters = GetAxesParams();

  std::set<std::string> keys;
  for (auto&& label : axesParameters)
  {
    keys.insert(label.first);
  }
  auto it = keys.find(alcKey);
  if (it == keys.end())
  {
    std::string res =
        "Invalid key for axes labels and colors.\nValid keys are: ";
    for (const auto& [key, value] : axesParameters)
    {
      res += fmt::format("{:s}, ", key);
    }
    if (res.length() >= 2)
    {
      auto pos = res.length() - 2;
      res.replace(pos, 2, "");
    }
    res += "\nUsing the key: xyz";
    std::cout << res << std::endl;
    alcKey = "xyz";
  }
  auto alc = axesParameters[alcKey];

  vtkNew<vtkCameraOrientationRepresentation> rep;

  switch (position)
  {
  case 0:
    rep->AnchorToLowerLeft();
    break;
  case 1:
    rep->AnchorToUpperLeft();
    break;
  case 2:
    rep->AnchorToLowerRight();
    break;
  default:
    rep->AnchorToUpperRight();
  }

  if (!alc.first.empty())
  {
    rep->SetXPlusLabelText(alc.first["+X"]);
    rep->SetXMinusLabelText(alc.first["-X"]);
    rep->SetYPlusLabelText(alc.first["+Y"]);
    rep->SetYMinusLabelText(alc.first["-Y"]);
    rep->SetZPlusLabelText(alc.first["+Z"]);
    rep->SetZMinusLabelText(alc.first["-Z"]);
  }

  if (!alc.second.empty())
  {
    vtkNew<vtkNamedColors> colors;

    rep->SetXAxisColor(colors->GetColor3d(alc.second["+X"]).GetData());
    rep->SetYAxisColor(colors->GetColor3d(alc.second["+Y"]).GetData());
    rep->SetZAxisColor(colors->GetColor3d(alc.second["+Z"]).GetData());
  }

  cow->SetRepresentation(rep);

  cow->Off();

  return cow;
}

} // namespace
