#include <vtkActor.h>
#include <vtkConeSource.h>
#include <vtkDiscretizableColorTransferFunction.h>
#include <vtkElevationFilter.h>
#include <vtkInteractorStyleTrackballCamera.h>
#include <vtkNamedColors.h>
#include <vtkNew.h>
#include <vtkPolyDataMapper.h>
#include <vtkProperty.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkRenderer.h>
#include <vtkSmartPointer.h>
#include <vtkSphereSource.h>

#include <vtk_cli11.h>
#include <vtk_fmt.h>
// clang-format off
#include VTK_FMT(fmt/format.h)
// clang-format on

namespace fs = std::filesystem;

namespace {
/**
 * @brief GetFastCTF Generate the color transfer function.
 *
 * name: Fast, creator: Francesca Samsel, and Alan W. Scott
 * interpolationspace: Lab, space: rgb
 * file name: Fast.json
 *
 * @param discretize: Selects whether the CTF is discretized or not.
 * @param reverse: Reverse the colors in the CTF.
 *
 * @return The color transfer function.
 */
vtkNew<vtkDiscretizableColorTransferFunction>
GetFastCTF(bool const& discretize = true, bool const& reverse = false);

} // namespace

int main(int argc, char* argv[])
{
  CLI::App app{"Display a cone using the vtkDiscretizableColorTransferFunction "
               "to generate the colormap."};

  // Define options.
  auto useSphere{false};
  app.add_flag("-s, --sphere", useSphere, "Use a sphere.");

  auto continuous{false};
  app.add_flag("-c, --continuous", continuous, "Build a continuous colormap.");

  auto reverse{false};
  app.add_flag("-r, --reverse", reverse, "Reverse the colormap.");

  CLI11_PARSE(app, argc, argv);

  auto discretize = !continuous;

  vtkNew<vtkNamedColors> colors;

  vtkNew<vtkRenderer> ren;
  ren->SetBackground(colors->GetColor3d("ParaViewBlueGrayBkg").GetData());
  vtkNew<vtkRenderWindow> renWin;
  renWin->SetSize(640, 480);
  auto appFn = fs::path((app.get_name())).stem().string();
  renWin->SetWindowName(appFn.c_str());
  renWin->AddRenderer(ren);
  vtkNew<vtkRenderWindowInteractor> iRen;
  iRen->SetRenderWindow(renWin);

  vtkNew<vtkInteractorStyleTrackballCamera> style;
  iRen->SetInteractorStyle(style);

  vtkSmartPointer<vtkPolyData> source;
  if (useSphere)
  {
    vtkNew<vtkSphereSource> sphere;
    sphere->SetThetaResolution(64);
    sphere->SetPhiResolution(32);
    sphere->Update();
    source = sphere->GetOutput();
  }
  else
  {
    vtkNew<vtkConeSource> cone;
    cone->SetResolution(6);
    cone->SetDirection(0, 1, 0);
    cone->SetHeight(1);
    cone->Update();
    source = cone->GetOutput();
  }
  auto bounds = source->GetBounds();

  vtkNew<vtkElevationFilter> elevation_filter;
  elevation_filter->SetLowPoint(0, bounds[2], 0);
  elevation_filter->SetHighPoint(0, bounds[3], 0);
  elevation_filter->SetInputData(source);

  auto ctf = GetFastCTF(discretize, reverse);

  vtkNew<vtkPolyDataMapper> mapper;
  mapper->SetInputConnection(elevation_filter->GetOutputPort());
  mapper->SetLookupTable(ctf);
  mapper->SetColorModeToMapScalars();
  mapper->InterpolateScalarsBeforeMappingOn();

  vtkNew<vtkActor> actor;
  actor->SetMapper(mapper);

  ren->AddActor(actor);

  renWin->Render();
  iRen->Start();

  return EXIT_SUCCESS;
}

namespace {
vtkNew<vtkDiscretizableColorTransferFunction> GetFastCTF(bool const& discretize,
                                                         bool const& reverse)
{

  std::map<double, std::array<double, 3>> ptsRGB{
      {0, {0.05639999999999999, 0.05639999999999999, 0.47}},
      {0.17159223942480895, {0.24300000000000013, 0.4603500000000004, 0.81}},
      {0.2984914818394138,
       {0.3568143826543521, 0.7450246485363142, 0.954367702893722}},
      {0.4321287371255907, {0.6882, 0.93, 0.9179099999999999}},
      {0.5, {0.8994959551205902, 0.944646394975174, 0.7686567142818399}},
      {0.5882260353170073,
       {0.957107977357604, 0.8338185108985666, 0.5089156299842102}},
      {0.7061412605695164,
       {0.9275207599610714, 0.6214389091739178, 0.31535705838676426}},
      {0.8476395308725272, {0.8, 0.3520000000000001, 0.15999999999999998}},
      {1, {0.59, 0.07670000000000013, 0.11947499999999994}},
  };

  std::vector<double> indices;
  indices.reserve(ptsRGB.size());
  for (const auto& pair : ptsRGB)
  {
    indices.push_back(pair.first);
  }
  std::vector<double> indicesRev(indices.rbegin(), indices.rend());

  vtkNew<vtkDiscretizableColorTransferFunction> ctf;
  ctf->SetColorSpaceToLab();
  ctf->SetScaleToLinear();
  ctf->SetNumberOfValues(ptsRGB.size());
  ctf->SetNanColor(0.0, 1.0, 0.0);
  ctf->SetDiscretize(discretize);

  if (reverse)
  {
    auto idx = 0;
    for (auto const indexRev : indicesRev)
    {
      auto index = indices[idx];
      idx += 1;
      auto rgb = ptsRGB[index];
      ctf->AddRGBPoint(indexRev, rgb[0], rgb[1], rgb[2]);
    }
  }
  else
  {
    for (auto const index : indices)
    {
      auto rgb = ptsRGB[index];
      ctf->AddRGBPoint(index, rgb[0], rgb[1], rgb[2]);
    }
  }

  return ctf;
}

} // namespace
