#include <vtkActor.h>
#include <vtkActor2D.h>
#include <vtkCallbackCommand.h>
#include <vtkCommand.h>
#include <vtkGlyph3DMapper.h>
#include <vtkKochanekSpline.h>
#include <vtkNamedColors.h>
#include <vtkNew.h>
#include <vtkParametricFunctionSource.h>
#include <vtkParametricSpline.h>
#include <vtkPoints.h>
#include <vtkPolyData.h>
#include <vtkPolyDataMapper.h>
#include <vtkProperty.h>
#include <vtkProperty2D.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkRenderer.h>
#include <vtkSliderRepresentation2D.h>
#include <vtkSliderWidget.h>
#include <vtkSphereSource.h>
#include <vtkTextMapper.h>
#include <vtkTextProperty.h>

namespace {
/**
 * @brief The Slider2DProperties struct.
 *
 * These are the default properties.
 * Instantiate the struct and modify as appropriate.
 *
 * @return The properties.
 */
struct Slider2DProperties
{
  struct _Colors
  {
    // The color of the text indicating what the slider controls.
    std::string titleColor{"White"};
    // The color of the text displaying the value.
    std::string labelColor{"White"};
    // The color of the knob that slides.
    std::string sliderColor{"White"};
    // The color of the bar.
    std::string barColor{"White"};
    // The color of the ends of the bar.
    std::string barEndsColor{"White"};
    // The color of the knob when the mouse is held on it.
    std::string selectedColor{"HotPink"};
  };

  struct _Dimensions
  {
    double tubeWidth{0.008};
    double sliderLength{0.01};
    double sliderWidth{0.02};
    double endCapLength{0.005};
    double endCapWidth{0.05};
    double titleHeight{0.03};
    double labelHeight{0.025};
  };

  struct _Position
  {
    int coordinateSystem = VTK_NORMALIZED_VIEWPORT;
    std::array<double, 2> point1{0.1, 0.1};
    std::array<double, 2> point2{0.9, 0.1};
  };

  struct _Range
  {
    double minimumValue{0.0};
    double maximumValue{1.0};
    double value{0.0};
  };

  struct _Text
  {
    // Font families are: Ariel, Courier and Times
    std::string title{};
    std::string titleFontFamily{"Arial"};
    bool titleBold{true};
    bool titleItalic{false};
    bool titleShadow{true};
    std::string labelFontFamily{"Arial"};
    bool labelBold{true};
    bool labelItalic{false};
    bool labelShadow{true};
  };

  struct _Colors Colors;
  struct _Dimensions Dimensions;
  struct _Position Position;
  struct _Range Range;
  struct _Text Text;
};

/**
 * @brief MakeSlider2DProperties
 *
 * This applies more specific values to the default Slider2DProperties.
 *
 * @return The slider 2D properties.
 */
Slider2DProperties MakeSlider2DProperties();

/**
 * @brief Make2DSliderWidget
 *
 * Make a 2D slider widget.
 *
 * @param properties The 2D slider properties.
 * @param iren The vtkInteractor.
 * @return The slider widget.
 */
vtkNew<vtkSliderWidget> Make2DSliderWidget(Slider2DProperties const& properties,
                                           vtkRenderWindowInteractor* iren);

// This does the actual work.
// Callback for the interaction.
class SliderCallbackTension : public vtkCommand
{
public:
  static SliderCallbackTension* New()
  {
    return new SliderCallbackTension;
  }
  virtual void Execute(vtkObject* caller, unsigned long, void*)
  {
    vtkSliderWidget* sliderWidget = reinterpret_cast<vtkSliderWidget*>(caller);
    double value = static_cast<vtkSliderRepresentation2D*>(
                       sliderWidget->GetRepresentation())
                       ->GetValue();
    dynamic_cast<vtkKochanekSpline*>(this->spline->GetXSpline())
        ->SetDefaultTension(value);
    dynamic_cast<vtkKochanekSpline*>(this->spline->GetYSpline())
        ->SetDefaultTension(value);
    dynamic_cast<vtkKochanekSpline*>(this->spline->GetZSpline())
        ->SetDefaultTension(value);
    source->Modified();
  }
  SliderCallbackTension() : spline(0), source(0)
  {
  }
  vtkParametricSpline* spline;
  vtkParametricFunctionSource* source;
};

class SliderCallbackContinuity : public vtkCommand
{
public:
  static SliderCallbackContinuity* New()
  {
    return new SliderCallbackContinuity;
  }
  virtual void Execute(vtkObject* caller, unsigned long, void*)
  {
    vtkSliderWidget* sliderWidget = reinterpret_cast<vtkSliderWidget*>(caller);
    double value = static_cast<vtkSliderRepresentation2D*>(
                       sliderWidget->GetRepresentation())
                       ->GetValue();
    dynamic_cast<vtkKochanekSpline*>(this->spline->GetXSpline())
        ->SetDefaultTension(value);
    dynamic_cast<vtkKochanekSpline*>(this->spline->GetYSpline())
        ->SetDefaultTension(value);
    dynamic_cast<vtkKochanekSpline*>(this->spline->GetZSpline())
        ->SetDefaultTension(value);
    source->Modified();
  }
  SliderCallbackContinuity() : spline(0), source(0)
  {
  }
  vtkParametricSpline* spline;
  vtkParametricFunctionSource* source;
};

class SliderCallbackBias : public vtkCommand
{
public:
  static SliderCallbackBias* New()
  {
    return new SliderCallbackBias;
  }
  virtual void Execute(vtkObject* caller, unsigned long, void*)
  {
    vtkSliderWidget* sliderWidget = reinterpret_cast<vtkSliderWidget*>(caller);
    double value = static_cast<vtkSliderRepresentation2D*>(
                       sliderWidget->GetRepresentation())
                       ->GetValue();
    dynamic_cast<vtkKochanekSpline*>(this->spline->GetXSpline())
        ->SetDefaultTension(value);
    dynamic_cast<vtkKochanekSpline*>(this->spline->GetYSpline())
        ->SetDefaultTension(value);
    dynamic_cast<vtkKochanekSpline*>(this->spline->GetZSpline())
        ->SetDefaultTension(value);
    source->Modified();
  }
  SliderCallbackBias() : spline(0), source(0)
  {
  }
  vtkParametricSpline* spline;
  vtkParametricFunctionSource* source;
};
} // namespace

int main(int, char*[])
{
  vtkNew<vtkNamedColors> colors;

  int numberOfPoints = 7;
  vtkNew<vtkPoints> points;
  points->SetNumberOfPoints(numberOfPoints);
  double radius = 1.0;
  double delta = 2.0 * vtkMath::Pi() / double(numberOfPoints);
  for (int n = 0; n < numberOfPoints; ++n)
  {
    double theta = delta * n;
    double x = radius * std::cos(theta);
    double y = radius * std::sin(theta);
    double z = n * (vtkMath::Pi() / numberOfPoints);
    points->SetPoint(n, x, y, z);
  }

  vtkNew<vtkKochanekSpline> xSpline;
  vtkNew<vtkKochanekSpline> ySpline;
  vtkNew<vtkKochanekSpline> zSpline;

  vtkNew<vtkParametricSpline> spline;
  spline->SetXSpline(xSpline);
  spline->SetYSpline(ySpline);
  spline->SetZSpline(zSpline);
  spline->SetPoints(points);

  auto resolution = 50 * numberOfPoints;
  vtkNew<vtkParametricFunctionSource> functionSource;
  functionSource->SetParametricFunction(spline);
  functionSource->SetUResolution(resolution);
  functionSource->SetVResolution(resolution);
  functionSource->SetWResolution(resolution);
  functionSource->Update();

  // Setup actor and mapper.
  vtkNew<vtkPolyDataMapper> mapper;
  mapper->SetInputConnection(functionSource->GetOutputPort());

  vtkNew<vtkActor> actor;
  actor->SetMapper(mapper);
  actor->GetProperty()->SetColor(colors->GetColor3d("DarkSlateGrey").GetData());
  actor->GetProperty()->SetLineWidth(3.0);

  // Glyph the points.
  vtkNew<vtkSphereSource> sphere;
  sphere->SetPhiResolution(21);
  sphere->SetThetaResolution(21);
  sphere->SetRadius(0.1);

  // Create a polydata to store everything in.
  vtkNew<vtkPolyData> polyData;
  polyData->SetPoints(points);

  vtkNew<vtkGlyph3DMapper> pointMapper;
  pointMapper->SetInputData(polyData);
  pointMapper->SetSourceConnection(sphere->GetOutputPort());

  vtkNew<vtkActor> pointActor;
  pointActor->SetMapper(pointMapper);
  pointActor->GetProperty()->SetColor(colors->GetColor3d("Gold").GetData());
  pointActor->GetProperty()->SetOpacity(0.75);

  // Setup render window, renderer, and interactor.
  vtkNew<vtkRenderer> renderer;
  renderer->SetBackground(colors->GetColor3d("SlateGray").GetData());
  vtkNew<vtkRenderWindow> renderWindow;
  renderWindow->AddRenderer(renderer);
  renderWindow->SetSize(640, 480);
  renderWindow->SetWindowName("KochanekSpline");

  vtkNew<vtkRenderWindowInteractor> renderWindowInteractor;
  renderWindowInteractor->SetRenderWindow(renderWindow);

  renderer->AddActor(actor);
  renderer->AddActor(pointActor);

  renderWindow->Render();

  auto sp1 = MakeSlider2DProperties();
  sp1.Text.title = "Tension";
  sp1.Position.point1 = std::array<double, 2>{0.05, 0.1};
  sp1.Position.point2 = std::array<double, 2>{0.45, 0.1};

  auto tensionWidget = Make2DSliderWidget(sp1, renderWindowInteractor);
  vtkNew<SliderCallbackTension> tensionCb;
  tensionCb->spline = spline;
  tensionCb->source = functionSource;
  tensionWidget->AddObserver(vtkCommand::InteractionEvent, tensionCb);

  auto sp2 = MakeSlider2DProperties();
  sp2.Text.title = "Continuity";
  sp2.Position.point1 = std::array<double, 2>{0.55, 0.1};
  sp2.Position.point2 = std::array<double, 2>{0.95, 0.1};

  auto continuityWidget = Make2DSliderWidget(sp2, renderWindowInteractor);
  vtkNew<SliderCallbackContinuity> continuityCb;
  continuityCb->spline = spline;
  continuityCb->source = functionSource;
  continuityWidget->AddObserver(vtkCommand::InteractionEvent, continuityCb);

  auto sp3 = MakeSlider2DProperties();
  sp3.Text.title = "Bias";
  sp3.Position.point1 = std::array<double, 2>{0.85, 0.2};
  sp3.Position.point2 = std::array<double, 2>{0.85, 0.8};

  auto biasWidget = Make2DSliderWidget(sp3, renderWindowInteractor);
  vtkNew<SliderCallbackBias> biasCb;
  biasCb->spline = spline;
  biasCb->source = functionSource;
  biasWidget->AddObserver(vtkCommand::InteractionEvent, biasCb);

  renderWindow->Render();
  renderWindowInteractor->Start();

  return EXIT_SUCCESS;
}

namespace {

Slider2DProperties MakeSlider2DProperties()
{
  auto sp = Slider2DProperties();

  // Set color properties:
  // Change the color of the knob that slides.
  sp.Colors.sliderColor = "Green";
  // Change the color of the text indicating what the slider controls.
  sp.Colors.titleColor = "PeachPuff";
  // Change the color of the text displaying the value.
  sp.Colors.labelColor = "AliceBlue";
  // Change the color of the knob when the mouse is held on it.
  sp.Colors.selectedColor = "DeepPink";
  // Change the color of the bar.
  sp.Colors.barColor = "MistyRose";
  // Change the color of the ends of the bar.
  sp.Colors.barEndsColor = "Yellow";
  sp.Dimensions.sliderLength = 0.05;
  sp.Dimensions.sliderWidth = 0.025;
  sp.Dimensions.endCapLength = 0.02;
  sp.Dimensions.titleHeight = 0.045;
  sp.Dimensions.labelHeight = 0.035;
  sp.Position.point1 = std::array<double, 2>{0.3, 0.1};
  sp.Position.point2 = std::array<double, 2>{0.7, 0.1};
  sp.Range.minimumValue = -1.0;
  sp.Range.maximumValue = 1.0;
  sp.Range.value = 0;

  return sp;
}

vtkNew<vtkSliderWidget> Make2DSliderWidget(Slider2DProperties const& properties,
                                           vtkRenderWindowInteractor* iren)
{
  vtkNew<vtkNamedColors> colors;

  vtkNew<vtkSliderRepresentation2D> sliderRep;

  sliderRep->SetMinimumValue(properties.Range.minimumValue);
  sliderRep->SetMaximumValue(properties.Range.maximumValue);
  sliderRep->SetValue(properties.Range.value);
  sliderRep->SetTitleText(properties.Text.title.c_str());
  sliderRep->SetTubeWidth(properties.Dimensions.tubeWidth);
  sliderRep->SetSliderLength(properties.Dimensions.sliderLength);
  sliderRep->SetSliderWidth(properties.Dimensions.sliderWidth);
  sliderRep->SetEndCapLength(properties.Dimensions.endCapLength);
  sliderRep->SetEndCapWidth(properties.Dimensions.endCapWidth);
  sliderRep->SetTitleHeight(properties.Dimensions.titleHeight);
  sliderRep->SetLabelHeight(properties.Dimensions.labelHeight);

  // Set the color properties.
  sliderRep->GetTitleProperty()->SetColor(
      colors->GetColor3d(properties.Colors.titleColor).GetData());
  sliderRep->GetLabelProperty()->SetColor(
      colors->GetColor3d(properties.Colors.labelColor).GetData());
  sliderRep->GetTubeProperty()->SetColor(
      colors->GetColor3d(properties.Colors.barColor).GetData());
  sliderRep->GetCapProperty()->SetColor(
      colors->GetColor3d(properties.Colors.barEndsColor).GetData());
  sliderRep->GetSliderProperty()->SetColor(
      colors->GetColor3d(properties.Colors.sliderColor).GetData());
  sliderRep->GetSelectedProperty()->SetColor(
      colors->GetColor3d(properties.Colors.selectedColor).GetData());

  // Set the position.
  sliderRep->GetPoint1Coordinate()->SetCoordinateSystem(
      properties.Position.coordinateSystem);
  sliderRep->GetPoint1Coordinate()->SetValue(properties.Position.point1.data());
  sliderRep->GetPoint2Coordinate()->SetCoordinateSystem(
      properties.Position.coordinateSystem);
  sliderRep->GetPoint2Coordinate()->SetValue(properties.Position.point2.data());

  std::string titleFontFamily = properties.Text.titleFontFamily;
  if (titleFontFamily == "Courier")
  {
    sliderRep->GetLabelProperty()->SetFontFamilyToCourier();
  }
  else if (titleFontFamily == "Times")
  {
    sliderRep->GetLabelProperty()->SetFontFamilyToTimes();
  }
  else
  {
    sliderRep->GetLabelProperty()->SetFontFamilyToArial();
  }
  sliderRep->GetTitleProperty()->SetBold(properties.Text.titleBold);
  sliderRep->GetTitleProperty()->SetItalic(properties.Text.titleItalic);
  sliderRep->GetTitleProperty()->SetShadow(properties.Text.titleShadow);
  std::string labelFontFamily = properties.Text.labelFontFamily;
  if (labelFontFamily == "Courier")
  {
    sliderRep->GetLabelProperty()->SetFontFamilyToCourier();
  }
  else if (labelFontFamily == "Times")
  {
    sliderRep->GetLabelProperty()->SetFontFamilyToTimes();
  }
  else
  {
    sliderRep->GetLabelProperty()->SetFontFamilyToArial();
  }
  sliderRep->GetLabelProperty()->SetBold(properties.Text.labelBold);
  sliderRep->GetLabelProperty()->SetItalic(properties.Text.labelItalic);
  sliderRep->GetLabelProperty()->SetShadow(properties.Text.labelShadow);

  vtkNew<vtkSliderWidget> widget;
  widget->SetInteractor(iren);
  widget->SetRepresentation(sliderRep);
  widget->EnabledOn();
  widget->SetAnimationModeToAnimate();

  return widget;
}

} // namespace

// namespace {
// // These callbacks do the actual work.
// // Callbacks for the interactions
// class SliderCallbackTension : public vtkCommand
// {
// public:
//   static SliderCallbackTension* New()
//   {
//     return new SliderCallbackTension;
//   }
//   virtual void Execute(vtkObject* caller, unsigned long, void*)
//   {
//     vtkSliderWidget* sliderWidget =
//     reinterpret_cast<vtkSliderWidget*>(caller); double value =
//     static_cast<vtkSliderRepresentation2D*>(
//                        sliderWidget->GetRepresentation())
//                        ->GetValue();
//     dynamic_cast<vtkKochanekSpline*>(this->ParametricSpline->GetXSpline())
//         ->SetDefaultTension(value);
//     dynamic_cast<vtkKochanekSpline*>(this->ParametricSpline->GetYSpline())
//         ->SetDefaultTension(value);
//     dynamic_cast<vtkKochanekSpline*>(this->ParametricSpline->GetZSpline())
//         ->SetDefaultTension(value);
//     ParametricSource->Modified();
//     ParametricSource->Update();
//   }
//   SliderCallbackTension() : ParametricSource(0), ParametricSpline(0)
//   {
//   }
//   vtkParametricSpline* ParametricSpline;
//   vtkParametricFunctionSource* ParametricSource;
// };

// void MakeTensionWidget(vtkSliderWidget* widget,
//                        vtkParametricFunctionSource* parametricSource,
//                        vtkParametricSpline* parametricSpline,
//                        vtkRenderer* renderer,
//                        vtkRenderWindowInteractor* interactor)
// {
//   // Setup a slider widget for each varying parameter.
//   double tubeWidth(.005);
//   double sliderLength(.02);
//   double titleHeight(.02);
//   double labelHeight(.02);

//   vtkNew<vtkSliderRepresentation2D> sliderRepTension;

//   sliderRepTension->SetRenderer(renderer);

//   sliderRepTension->SetMinimumValue(-1.0);
//   sliderRepTension->SetMaximumValue(1.0);
//   sliderRepTension->SetValue(
//       dynamic_cast<vtkKochanekSpline*>(parametricSpline->GetXSpline())
//           ->GetDefaultTension());
//   sliderRepTension->SetTitleText("Tension");
//   sliderRepTension->SetRenderer(renderer);
//   sliderRepTension->GetPoint1Coordinate()->SetValue(0.1, 0.1);
//   sliderRepTension->GetPoint1Coordinate()
//       ->SetCoordinateSystemToNormalizedViewport();
//   sliderRepTension->GetPoint2Coordinate()->SetValue(0.3, 0.1);
//   sliderRepTension->GetPoint2Coordinate()
//       ->SetCoordinateSystemToNormalizedViewport();

//   sliderRepTension->SetTubeWidth(tubeWidth);
//   sliderRepTension->SetSliderLength(sliderLength);
//   sliderRepTension->SetTitleHeight(titleHeight);
//   sliderRepTension->SetLabelHeight(labelHeight);
//   sliderRepTension->SetEndCapLength(tubeWidth * 1.5);
//   sliderRepTension->SetSliderWidth(tubeWidth * 1.5);
//   sliderRepTension->BuildRepresentation();
//   SetSliderColors(sliderRepTension);

//   widget->SetRepresentation(sliderRepTension);
//   widget->SetAnimationModeToAnimate();
//   widget->SetNumberOfAnimationSteps(10);
//   widget->SetInteractor(interactor);
//   widget->EnabledOn();

//   vtkNew<SliderCallbackTension> callbackTension;
//   callbackTension->ParametricSpline = parametricSpline;
//   callbackTension->ParametricSource = parametricSource;

//   widget->AddObserver(vtkCommand::InteractionEvent, callbackTension);
// }

// class SliderCallbackContinuity : public vtkCommand
// {
// public:
//   static SliderCallbackContinuity* New()
//   {
//     return new SliderCallbackContinuity;
//   }
//   virtual void Execute(vtkObject* caller, unsigned long, void*)
//   {
//     vtkSliderWidget* sliderWidget =
//     reinterpret_cast<vtkSliderWidget*>(caller); double value =
//     static_cast<vtkSliderRepresentation2D*>(
//                        sliderWidget->GetRepresentation())
//                        ->GetValue();
//     dynamic_cast<vtkKochanekSpline*>(this->ParametricSpline->GetXSpline())
//         ->SetDefaultContinuity(value);
//     dynamic_cast<vtkKochanekSpline*>(this->ParametricSpline->GetYSpline())
//         ->SetDefaultContinuity(value);
//     dynamic_cast<vtkKochanekSpline*>(this->ParametricSpline->GetZSpline())
//         ->SetDefaultContinuity(value);
//     ParametricSource->Modified();
//     ParametricSource->Update();
//   }
//   SliderCallbackContinuity() : ParametricSource(0), ParametricSpline(0)
//   {
//   }
//   vtkParametricSpline* ParametricSpline;
//   vtkParametricFunctionSource* ParametricSource;
// };

// void MakeContinuityWidget(vtkSliderWidget* widget,
//                           vtkParametricFunctionSource* parametricSource,
//                           vtkParametricSpline* parametricSpline,
//                           vtkRenderer* renderer,
//                           vtkRenderWindowInteractor* interactor)
// {
//   // Setup a slider widget for each varying parameter.
//   double tubeWidth(.005);
//   double sliderLength(.02);
//   double titleHeight(.02);
//   double labelHeight(.02);

//   vtkNew<vtkSliderRepresentation2D> sliderRepContinuity;

//   sliderRepContinuity->SetRenderer(renderer);

//   sliderRepContinuity->SetMinimumValue(-1.0);
//   sliderRepContinuity->SetMaximumValue(1.0);
//   sliderRepContinuity->SetValue(
//       dynamic_cast<vtkKochanekSpline*>(parametricSpline->GetXSpline())
//           ->GetDefaultContinuity());
//   sliderRepContinuity->SetTitleText("Continuity");
//   sliderRepContinuity->SetRenderer(renderer);
//   sliderRepContinuity->GetPoint1Coordinate()->SetValue(0.4, 0.1);
//   sliderRepContinuity->GetPoint1Coordinate()
//       ->SetCoordinateSystemToNormalizedViewport();
//   sliderRepContinuity->GetPoint2Coordinate()->SetValue(0.6, 0.1);
//   sliderRepContinuity->GetPoint2Coordinate()
//       ->SetCoordinateSystemToNormalizedViewport();

//   sliderRepContinuity->SetTubeWidth(tubeWidth);
//   sliderRepContinuity->SetSliderLength(sliderLength);
//   sliderRepContinuity->SetTitleHeight(titleHeight);
//   sliderRepContinuity->SetLabelHeight(labelHeight);
//   sliderRepContinuity->SetEndCapLength(tubeWidth * 1.5);
//   sliderRepContinuity->SetSliderWidth(tubeWidth * 1.5);
//   sliderRepContinuity->BuildRepresentation();
//   SetSliderColors(sliderRepContinuity);

//   widget->SetRepresentation(sliderRepContinuity);
//   widget->SetAnimationModeToAnimate();
//   widget->SetNumberOfAnimationSteps(10);
//   widget->SetInteractor(interactor);
//   widget->EnabledOn();

//   vtkNew<SliderCallbackContinuity> callbackContinuity;
//   callbackContinuity->ParametricSpline = parametricSpline;
//   callbackContinuity->ParametricSource = parametricSource;

//   widget->AddObserver(vtkCommand::InteractionEvent, callbackContinuity);
// }

// class SliderCallbackBias : public vtkCommand
// {
// public:
//   static SliderCallbackBias* New()
//   {
//     return new SliderCallbackBias;
//   }
//   virtual void Execute(vtkObject* caller, unsigned long, void*)
//   {
//     vtkSliderWidget* sliderWidget =
//     reinterpret_cast<vtkSliderWidget*>(caller); double value =
//     static_cast<vtkSliderRepresentation2D*>(
//                        sliderWidget->GetRepresentation())
//                        ->GetValue();
//     dynamic_cast<vtkKochanekSpline*>(this->ParametricSpline->GetXSpline())
//         ->SetDefaultBias(value);
//     dynamic_cast<vtkKochanekSpline*>(this->ParametricSpline->GetYSpline())
//         ->SetDefaultBias(value);
//     dynamic_cast<vtkKochanekSpline*>(this->ParametricSpline->GetZSpline())
//         ->SetDefaultBias(value);
//     ParametricSource->Modified();
//     ParametricSource->Update();
//   }
//   SliderCallbackBias() : ParametricSource(0), ParametricSpline(0)
//   {
//   }
//   vtkParametricSpline* ParametricSpline;
//   vtkParametricFunctionSource* ParametricSource;
// };

// void MakeBiasWidget(vtkSliderWidget* widget,
//                     vtkParametricFunctionSource* parametricSource,
//                     vtkParametricSpline* parametricSpline,
//                     vtkRenderer* renderer,
//                     vtkRenderWindowInteractor* interactor)
// {
//   // Setup a slider widget for each varying parameter.
//   double tubeWidth(.005);
//   double sliderLength(.02);
//   double titleHeight(.02);
//   double labelHeight(.02);

//   vtkNew<vtkSliderRepresentation2D> sliderRepBias;

//   sliderRepBias->SetRenderer(renderer);

//   sliderRepBias->SetMinimumValue(-1.0);
//   sliderRepBias->SetMaximumValue(1.0);
//   sliderRepBias->SetValue(
//       dynamic_cast<vtkKochanekSpline*>(parametricSpline->GetXSpline())
//           ->GetDefaultBias());
//   sliderRepBias->SetTitleText("Bias");
//   sliderRepBias->SetRenderer(renderer);
//   sliderRepBias->GetPoint1Coordinate()->SetValue(0.7, 0.1);
//   sliderRepBias->GetPoint1Coordinate()
//       ->SetCoordinateSystemToNormalizedViewport();
//   sliderRepBias->GetPoint2Coordinate()->SetValue(0.9, 0.1);
//   sliderRepBias->GetPoint2Coordinate()
//       ->SetCoordinateSystemToNormalizedViewport();

//   sliderRepBias->SetTubeWidth(tubeWidth);
//   sliderRepBias->SetSliderLength(sliderLength);
//   sliderRepBias->SetTitleHeight(titleHeight);
//   sliderRepBias->SetLabelHeight(labelHeight);
//   sliderRepBias->SetEndCapLength(tubeWidth * 1.5);
//   sliderRepBias->SetSliderWidth(tubeWidth * 1.5);
//   sliderRepBias->BuildRepresentation();
//   SetSliderColors(sliderRepBias);

//   widget->SetRepresentation(sliderRepBias);
//   widget->SetAnimationModeToAnimate();
//   widget->SetNumberOfAnimationSteps(10);
//   widget->SetInteractor(interactor);
//   widget->EnabledOn();

//   vtkNew<SliderCallbackBias> callbackBias;
//   callbackBias->ParametricSpline = parametricSpline;
//   callbackBias->ParametricSource = parametricSource;

//   widget->AddObserver(vtkCommand::InteractionEvent, callbackBias);
// }

// void SetSliderColors(vtkSliderRepresentation2D* slider)
// {
//   vtkNew<vtkNamedColors> colors;
//   // Set color properties:
//   // Change the color of the knob that slides.
//   slider->GetSliderProperty()->SetColor(colors->GetColor3d("Peru").GetData());
//   // Change the color of the text indicating what the slider controls.
//   slider->GetTitleProperty()->SetColor(
//       colors->GetColor3d("OrangeRed").GetData());
//   // Change the color of the text displaying the value.
//   slider->GetLabelProperty()->SetColor(
//       colors->GetColor3d("OrangeRed").GetData());
//   // Change the color of the knob when the mouse is held on it.
//   slider->GetSelectedProperty()->SetColor(
//       colors->GetColor3d("DeepPink").GetData());
//   // Change the color of the bar.
//   slider->GetTubeProperty()->SetColor(colors->GetColor3d("Gold").GetData());
//   // Change the color of the ends of the bar.
//   slider->GetCapProperty()->SetColor(colors->GetColor3d("Gold").GetData());
// }

// } // namespace
