#include <vtkImageActor.h>
#include <vtkImageCanvasSource2D.h>
#include <vtkImageMapper3D.h>
#include <vtkInteractorStyleImage.h>
#include <vtkNamedColors.h>
#include <vtkNew.h>
#include <vtkPNMReader.h>
#include <vtkPNMWriter.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkRenderer.h>

#include <iostream>

int main(int argc, char* argv[])
{
  vtkNew<vtkNamedColors> colors;

  if (argc != 2)
  {
    std::cout << "Required parameters: OutputFilename.pnm" << std::endl;
    return EXIT_FAILURE;
  }

  std::string filename = argv[1];

  vtkColor3ub color1;
  colors->GetColor("SteelBlue", color1);
  vtkColor3ub color2;
  colors->GetColor("PaleGoldenrod", color2);

  vtkNew<vtkImageCanvasSource2D> imageSource;
  imageSource->SetScalarTypeToUnsignedChar();
  imageSource->SetExtent(0, 9, 0, 9, 0, 0);
  imageSource->SetNumberOfScalarComponents(3);
  imageSource->SetDrawColor(color1.GetRed(), color1.GetGreen(),
                            color1.GetBlue());
  imageSource->FillBox(0, 9, 0, 9);
  imageSource->SetDrawColor(color2.GetRed(), color2.GetGreen(),
                            color2.GetBlue());
  imageSource->SetDrawColor(238, 232, 170);
  imageSource->FillBox(5, 7, 5, 7);
  imageSource->Update();

  vtkNew<vtkPNMWriter> pnmWriter;
  pnmWriter->SetFileName(filename.c_str());
  pnmWriter->SetInputConnection(imageSource->GetOutputPort());
  pnmWriter->Write();

  // Read and display for verification.
  vtkNew<vtkPNMReader> reader;
  reader->SetFileName(filename.c_str());
  reader->Update();

  vtkNew<vtkImageActor> actor;
  actor->GetMapper()->SetInputConnection(reader->GetOutputPort());

  // Setup renderer.
  vtkNew<vtkRenderer> renderer;
  renderer->AddActor(actor);
  renderer->SetBackground(colors->GetColor3d("DarkSlateGray").GetData());
  renderer->ResetCamera();

  // Setup render window.
  vtkNew<vtkRenderWindow> renderWindow;
  renderWindow->AddRenderer(renderer);
  renderWindow->SetWindowName("WritePNM");

  // Setup render window interactor
  vtkNew<vtkRenderWindowInteractor> renderWindowInteractor;
  vtkNew<vtkInteractorStyleImage> style;

  renderWindowInteractor->SetInteractorStyle(style);

  // Render and start interaction.
  renderWindowInteractor->SetRenderWindow(renderWindow);
  renderWindow->Render();
  renderWindowInteractor->Initialize();

  renderWindowInteractor->Start();

  return EXIT_SUCCESS;
}
