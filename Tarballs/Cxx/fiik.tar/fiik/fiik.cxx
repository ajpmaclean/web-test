#include <vtkActor.h>
#include <vtkConeSource.h>
#include <vtkCubeSource.h>
#include <vtkNamedColors.h>
#include <vtkNew.h>
#include <vtkPolyDataMapper.h>
#include <vtkProperty.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkRenderer.h>
#include <vtkSphereSource.h>
#include <vtkRendererCollection.h>
#include <vtkSmartPointer.h>
#include <vtkInteractorObserver.h>
#include <vtkInteractorStyleTrackballCamera.h>

#include <array>

namespace {
/**
 * Select the layer to manipulate.
 */
void SelectLayer(vtkObject* caller, long unsigned int eventId, void* clientData,
                 void* callData);

}
int main(int, char*[])
{
  vtkNew<vtkNamedColors> colors;

  // Set the background color.
  std::array<unsigned char, 4> cubeColor{{250, 128, 114, 255}};
  colors->SetColor("CubeColor", cubeColor.data());
  std::array<unsigned char, 4> bkg{{230, 230, 230, 255}};
  colors->SetColor("BkgColor", bkg.data());

  // Create the rendering windows and renderers.
  std::array<vtkSmartPointer<vtkRenderer>, 2> leftRends;
  std::array<vtkSmartPointer<vtkRenderer>, 2> rightRends;
  vtkNew<vtkRenderWindow> renWin;
  renWin->SetSize(1200, 600);
  renWin->SetPosition(0, 50);
  renWin->SetWindowName("fiik");
  renWin->SetNumberOfLayers(2);

  // The renderers in each render window.
  for (int i = 0; i < 2; ++i)
  {
      leftRends[i] = vtkSmartPointer<vtkRenderer>::New();
      leftRends[i]->SetViewport(0, 0, 0.5, 1);
      leftRends[i]->SetBackground(colors->GetColor3d("BkgColor").GetData());
      renWin->AddRenderer(leftRends[i]);
      rightRends[i] = vtkSmartPointer<vtkRenderer>::New();
      rightRends[i]->SetViewport(0.5, 0, 1, 1);
      rightRends[i]->SetBackground(colors->GetColor3d("Linen").GetData());
      renWin->AddRenderer(rightRends[i]);
  }
  // The layers for each renderer.
  for (int layer = 0; layer < 2; ++layer)
  {
    if (layer == 0)
    {
      leftRends[layer]->SetLayer(layer);
      rightRends[layer]->SetLayer(layer);
    }
    if (layer == 1)
    {
      leftRends[layer]->SetLayer(layer);
      rightRends[layer]->SetLayer(layer);
    }
  }

  vtkNew<vtkRenderWindowInteractor> iRen;
  iRen->SetRenderWindow(renWin);

  // Create an actor and give it cone geometry.
  vtkNew<vtkConeSource> cone;
  cone->SetResolution(8);

  vtkNew<vtkPolyDataMapper> coneMapper;
  coneMapper->SetInputConnection(cone->GetOutputPort());

  vtkNew<vtkActor> coneActor;
  coneActor->SetMapper(coneMapper);
  coneActor->GetProperty()->SetColor(colors->GetColor3d("Peacock").GetData());

  // Create an actor and give it cube geometry.
  vtkNew<vtkCubeSource> cube;

  vtkNew<vtkPolyDataMapper> cubeMapper;
  cubeMapper->SetInputConnection(cube->GetOutputPort());

  vtkNew<vtkActor> cubeActor;
  cubeActor->SetMapper(cubeMapper);
  cubeActor->GetProperty()->SetColor(colors->GetColor3d("CubeColor").GetData());


  // Assign our actor to both renderers.
  leftRends[1]->AddActor(coneActor);
  rightRends[1]->AddActor(cubeActor);


  // Draw the resulting scene.
  renWin->Render();

  iRen->Start();

  return EXIT_SUCCESS;
}

namespace {
void SelectLayer(vtkObject* caller, long unsigned int vtkNotUsed(eventId),
                 void* vtkNotUsed(clientData), void* vtkNotUsed(callData))
{
  vtkRenderWindowInteractor* iRen =
      static_cast<vtkRenderWindowInteractor*>(caller);
  vtkRendererCollection* renderers = iRen->GetRenderWindow()->GetRenderers();
  if (renderers->GetNumberOfItems() < 2)
  {
    std::cerr << "We need at least two renderers, we have only "
              << renderers->GetNumberOfItems() << std::endl;
    return;
  }
  renderers->InitTraversal();
  // Top item.
  vtkRenderer* ren0 = renderers->GetNextItem();
  // Bottom item.
  vtkRenderer* ren1 = renderers->GetNextItem();

  std::string key = iRen->GetKeySym();

  if (key == "0")
  {
    std::cout << "Selected layer: " << key << std::endl;
    iRen->GetRenderWindow()
        ->GetInteractor()
        ->GetInteractorStyle()
        ->SetDefaultRenderer(ren0);
    ren0->InteractiveOn();
    ren1->InteractiveOff();
  }
  if (key == "1")
  {
    std::cout << "Selected layer: " << key << std::endl;
    iRen->GetRenderWindow()
        ->GetInteractor()
        ->GetInteractorStyle()
        ->SetDefaultRenderer(ren1);
    ren0->InteractiveOff();
    ren1->InteractiveOn();
  }
}
}

/*
 * See: [The vtkActor show in multi renderwindow problem](https://discourse.vtk.org/t/the-vtkactor-show-in-multi-renderwindow-problem/14491/1)
void MoveActorToTop(vtkSmartPointer<vtkProp> actor)
 {
        if (leftWin_ != nullptr)
        {
            leftWin_ ->loewerRenderer_->RemoveActor(actor);
        }

     if (rightWin_ != nullptr)
     {
         rightWin_ ->loewerRenderer_->RemoveActor(actor);
     }

     if (leftWin_ != nullptr)
     {
         leftWin_ ->upperRenderer_->AddActor(actor);
     }

 if (rightWin_ != nullptr)
 {
     rightWin_ ->upperRenderer_->AddActor(actor);
 }
}

lowerRender_ = vtkSmartPointer<vtkRenderer>::New();
     lowerRender_ ->SetGradientBackground(true);
     lowerRender_ ->SetLayer(0);

     upperRender_ = vtkSmartPointer<vtkRenderer>::New();
     upperRender_ ->SetGradientBackground(true);
     upperRender_ ->SetLayer(1);
     // Set same camera as default render
     upperRender_ ->SetActiveCamera(lowerRender_->GetActiveCamera());

     renderWindow_->SetNumberOfLayers(2);
     renderWindow_->AddRenderer(lowerRender_);
     renderWindow_->AddRenderer(upperRender_ );

*/
