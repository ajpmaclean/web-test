#include <vtkCallbackCommand.h>
#include <vtkColorSeries.h>
#include <vtkCommand.h>
#include <vtkColorTransferFunction.h>
#include <vtkHDFReader.h>
#include <vtkInteractorStyleTrackballCamera.h>
#include <vtkLookupTable.h>
#include <vtkNamedColors.h>
#include <vtkNew.h>
#include <vtkObject.h>
#include <vtkObjectBase.h>
#include <vtkPointData.h>
#include <vtkPolyData.h>
#include <vtkCompositePolyDataMapper.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkRenderer.h>

#include <cstdlib>
#include <iostream>

namespace {
vtkLookupTable* GetCTF();

void Animate(vtkObject* caller, unsigned long /*eid*/, void* clientdata,
             void* /*calldata*/);

} // namespace

int main(int ac, char* av[])
{
  if (ac != 2)
  {
    std::cout << "Usage: " << av[0]
              << " filename.vtkhdf eg. warping_spheres.vtkhdf" << std::endl;
    return EXIT_FAILURE;
  }

  vtkNew<vtkNamedColors> colors;

  // Read the dataset.
  vtkNew<vtkHDFReader> reader;
  reader->SetFileName(av[1]);
  reader->Update();
  std::cout << "Number of steps: " << reader->GetNumberOfSteps() << endl;

  // Render the dataset.
  vtkNew<vtkCompositePolyDataMapper> mapper;
  mapper->SetInputConnection(reader->GetOutputPort());
  mapper->SetLookupTable(GetCTF());
  mapper->SetScalarModeToUsePointFieldData();
  mapper->SelectColorArray("SpatioTemporalHarmonics");

  vtkNew<vtkActor> actor;
  actor->SetMapper(mapper);

  vtkNew<vtkRenderer> renderer;
  renderer->SetBackground(colors->GetColor3d("AntiqueWhite").GetData());
  renderer->UseHiddenLineRemovalOn();
  renderer->AddActor(actor);

  vtkNew<vtkRenderWindow> renWin;
  renWin->AddRenderer(renderer);
  renWin->SetWindowName("TemporalHDFReader");
  renWin->SetSize(1024, 512);
  renWin->Render();

  // Add the interactor.
  vtkNew<vtkRenderWindowInteractor> iren;
  iren->SetRenderWindow(renWin);

  // Add the animation callback.
  vtkNew<vtkCallbackCommand> command;
  command->SetCallback(Animate);
  command->SetClientData(reader);

  // You must initialize the vtkRenderWindowInteractor
  // before adding the observer and setting the repeating timer.
  iren->Initialize();
  iren->AddObserver(vtkCommand::TimerEvent, command);
  iren->CreateRepeatingTimer(50);

  vtkNew<vtkInteractorStyleTrackballCamera> istyle;
  iren->SetInteractorStyle(istyle);

  iren->Start();

  return EXIT_SUCCESS;
}

namespace {
vtkLookupTable* GetCTF()
{
  vtkNew<vtkColorSeries> series;
  series->SetColorScheme(vtkColorSeries::WARM);
  return series->CreateLookupTable(vtkColorSeries::ORDINAL);    
}

void Animate(vtkObject* caller, unsigned long /*eid*/, void* clientdata,
             void* /*calldata*/)
{
  vtkRenderWindowInteractor* interactor =
      vtkRenderWindowInteractor::SafeDownCast(caller);
  vtkHDFReader* reader =
      vtkHDFReader::SafeDownCast(static_cast<vtkObjectBase*>(clientdata));
  reader->SetStep((reader->GetStep() == reader->GetNumberOfSteps() - 1)
                      ? 0
                      : reader->GetStep() + 1);
  std::cout << "Current step: " << reader->GetStep() << std::endl;
  reader->Update();
  interactor->Render();
}
} // namespace
