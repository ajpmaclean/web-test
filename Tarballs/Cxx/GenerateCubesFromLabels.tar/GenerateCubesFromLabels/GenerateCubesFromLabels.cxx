//
// GenerateCubesFromLabels
//   Usage: GenerateCubesFromLabels InputVolume Startlabel Endlabel
//          where
//          InputVolume is a meta file containing a 3 volume of
//            discrete labels.
//          StartLabel is the first label to be processed
//          EndLabel is the last label to be processed
//          NOTE: There can be gaps in the labeling. If a label does
//          not exist in the volume, it will be skipped.
//
//
#include <vtkCamera.h>
#include <vtkCameraOrientationRepresentation.h>
#include <vtkCameraOrientationWidget.h>
#include <vtkCellData.h>
#include <vtkGeometryFilter.h>
#include <vtkImageData.h>
#include <vtkImageWrapPad.h>
#include <vtkMetaImageReader.h>
#include <vtkNamedColors.h>
#include <vtkNew.h>
#include <vtkPointData.h>
#include <vtkPolyDataMapper.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkRenderer.h>
#include <vtkThreshold.h>
#include <vtkTransform.h>
#include <vtkTransformFilter.h>

#include <vtk_cli11.h>
#include <vtk_fmt.h>
// clang-format off
#include VTK_FMT(fmt/format.h)
// clang-format on

namespace fs = std::filesystem;

namespace {

typedef std::map<std::string, std::string> TAxisParams;
typedef std::map<std::string, TAxisParams> TAxesParams;

/**
 * @brief Define the axes labels.
 *
 * @return The axes labels.
 */
TAxesParams DefineAxesLabels();

/**
 * @brief Define the axes colors.
 *
 * @return The axes colors.
 */
TAxesParams DefineAxesColors();

/**
 * @brief Gather the defined axes labels and colors into a map.
 *
 * @return The map of axes labels and colors.
 */
std::map<std::string, std::pair<TAxisParams, TAxisParams>> GetAxesParams();

/**
 * @brief Make a camera orientation widget for a given renderer.
 *
 * position has these values 0: LowerLeft, 1: UpperLeft, 2: LowerRight, 3:
 * UpperRight
 *
 * @param ren The renderer.
 * @param alc The key specifying the desired labels and colors for the axes.
 * @param colors A reference to the vtkNamedColors object.
 * @param position Move the camera orientation widget to upper left.
 *
 * @return The camera orientation widget.
 */
vtkNew<vtkCameraOrientationWidget>
MakeCameraOrientationWidget(vtkRenderer* ren, std::string alcKey = "xyz",
                            int const& position = 3);
} // namespace
int main(int argc, char* argv[])
{
  CLI::App app{
      "View the results of a segmentation without any post processing."
      " The point data from a labeled volume is converted into cell data."};

  // Define options
  std::string fileName;
  app.add_option("fileName", fileName, "Input volume e.g. Frog/frogtissue.mhd.")
      ->required()
      ->check(CLI::ExistingFile);
  unsigned int startLabel{1};
  app.add_option("startLabel", startLabel,
                 "The starting label in the input volume, e.g. 1.");
  unsigned int endLabel{29};
  app.add_option("endLabel", endLabel,
                 "The ending label in the input volume, e.g. 29.");

  CLI11_PARSE(app, argc, argv);

  if (startLabel > endLabel)
  {
    auto tmp = endLabel;
    endLabel = startLabel;
    startLabel = tmp;
  }

  vtkNew<vtkNamedColors> colors;

  // Generate cubes from labels.
  // 1) Read the meta file
  // 2) Convert point data to cell data
  // 3) Convert to geometry and display

  vtkNew<vtkMetaImageReader> reader;
  reader->SetFileName(argv[1]);
  reader->Update();

  // Pad the volume so that we can change the point data into cell.
  // data.
  int* extent = reader->GetOutput()->GetExtent();
  vtkNew<vtkImageWrapPad> pad;
  pad->SetInputConnection(reader->GetOutputPort());
  pad->SetOutputWholeExtent(extent[0], extent[1] + 1, extent[2], extent[3] + 1,
                            extent[4], extent[5] + 1);
  pad->Update();

  // Copy the scalar point data of the volume into the scalar cell data.
  pad->GetOutput()->GetCellData()->SetScalars(
      reader->GetOutput()->GetPointData()->GetScalars());

  vtkNew<vtkThreshold> selector;
  selector->SetInputArrayToProcess(0, 0, 0,
                                   vtkDataObject::FIELD_ASSOCIATION_CELLS,
                                   vtkDataSetAttributes::SCALARS);
  selector->SetInputConnection(pad->GetOutputPort());
  selector->SetLowerThreshold(startLabel);
  selector->SetUpperThreshold(endLabel);
  selector->Update();

  // Shift the geometry by 1/2.
  vtkNew<vtkTransform> transform;
  transform->Translate(-0.5, -0.5, -0.5);

  vtkNew<vtkTransformFilter> transformModel;
  transformModel->SetTransform(transform);
  transformModel->SetInputConnection(selector->GetOutputPort());

  vtkNew<vtkGeometryFilter> geometry;
  geometry->SetInputConnection(transformModel->GetOutputPort());

  vtkNew<vtkPolyDataMapper> mapper;
  mapper->SetInputConnection(geometry->GetOutputPort());
  mapper->SetScalarRange(startLabel, endLabel);
  mapper->SetScalarModeToUseCellData();
  mapper->SetColorModeToMapScalars();

  vtkNew<vtkActor> actor;
  actor->SetMapper(mapper);

  vtkNew<vtkRenderer> ren;
  vtkNew<vtkRenderWindow> renWin;
  renWin->AddRenderer(ren);
  renWin->SetSize(640, 480);
  auto appFn = fs::path((app.get_name())).stem().string();
  renWin->SetWindowName(appFn.c_str());

  vtkNew<vtkRenderWindowInteractor> iRen;
  iRen->SetRenderWindow(renWin);

  ren->AddActor(actor);
  ren->SetBackground(colors->GetColor3d("DarkSlateBlue").GetData());
  renWin->Render();

  auto camera = ren->GetActiveCamera();
  camera->SetPosition(130.171200, 942.438334, -262.344068);
  camera->SetFocalPoint(279.491372, 262.325784, 172.209964);
  camera->SetViewUp(0.235239, -0.486113, -0.841639);
  camera->SetDistance(820.784260);
  camera->SetClippingRange(224.710879, 1514.926115);

  // Important: The interactor must be set prior to enabling the widget.
  auto cow = MakeCameraOrientationWidget(ren, "xyz", 3);
  cow->On();

  auto category = "aprlvd";
  auto cow1 = MakeCameraOrientationWidget(ren, category, 1);
  cow1->On();

  iRen->Start();
  return EXIT_SUCCESS;
}

namespace {
TAxesParams DefineAxesLabels()
{
  // clang-format off
  return {
          // Labels are: Anterior, Posterior, Dorsal, Ventral, Left, Right
          {"apdvlr", {{"+X", "A"},{"-X", "P"},{"+Y", "D"},{"-Y", "V"},{"+Z", "L"},{"-Z", "R"}}},
          {"apdvrl",{{"+X", "A"},{"-X", "P"},{"+Y", "D"},{"-Y", "V"},{"+Z", "R"},{"-Z", "L"}}},
          {"aprlvd",{{"+X", "A"},{"-X", "P"},{"+Y", "R"},{"-Y", "L"},{"+Z", "V"},{"-Z", "D"}}},
          {"padvlr", {{"+X", "P"},{"-X", "A"},{"+Y", "D"},{"-Y", "V"},{"+Z", "L"},{"-Z", "R"}}},
          // Labels are: Left, Right, Superior, Inferior, Anterior, Posterior
          {"lrsiap",{{"+X", "L"},{"-X", "R"},{"+Y", "S"},{"-Y", "I"},{"+Z", "A"},{"-Z", "P"}}},
          {"lrpasi",{{"+X", "L"},{"-X", "R"},{"+Y", "P"},{"-Y", "A"},{"+Z", "S"},{"-Z", "I"}}},
          {"rlpais",{{"+X", "R"},{"-X", "L"},{"+Y", "P"},{"-Y", "A"},{"+Z", "I"},{"-Z", "S"}}},
          // Default labels.
          {"xyz", {}},
          };
  // clang-format on
}

TAxesParams DefineAxesColors()
{
  // clang-format off
  TAxisParams color1{{"+X", "IndianRed"},{"-X", "FireBrick"},
                     {"+Y", "LimeGreen"},{"-Y", "DarkGreen"},
                     {"+Z", "Blue"}, {"-Z", "SteelBlue"}};
  return {
          {"apdvlr",color1},
          {"apdvrl",color1},
          {"aprlvd",color1},
          {"padvlr",color1},
          {"lrsiap",color1},
          // Default colors.
          {"lrpasi", {}},
          {"rlpais", {}},
          {"xyz", {}},
          };
  // clang-format on
}

std::map<std::string, std::pair<TAxisParams, TAxisParams>> GetAxesParams()
{
  vtkNew<vtkNamedColors> colors;

  // The keys must be the same.
  auto axesLabels = DefineAxesLabels();
  auto axesColors = DefineAxesColors();
  // Get the keys.
  std::set<std::string> labelKeys;
  for (auto&& label : axesLabels)
  {
    labelKeys.insert(label.first);
  }
  std::set<std::string> colorKeys;
  for (auto&& label : axesLabels)
  {
    colorKeys.insert(label.first);
  }
  std::vector<std::string> commonKeys;
  std::set_intersection(labelKeys.begin(), labelKeys.end(), colorKeys.begin(),
                        colorKeys.end(), std::back_inserter(commonKeys));
  std::map<std::string, std::pair<TAxisParams, TAxisParams>> alc;
  for (auto&& k : commonKeys)
  {
    alc[k] = std::pair<TAxisParams, TAxisParams>{axesLabels[k], axesColors[k]};
  }

  return alc;
};

vtkNew<vtkCameraOrientationWidget>
MakeCameraOrientationWidget(vtkRenderer* ren, std::string alcKey,
                            int const& position)
{

  vtkNew<vtkCameraOrientationWidget> cow;
  cow->SetParentRenderer(ren);
  cow->EnabledOn();

  auto axesParameters = GetAxesParams();

  std::set<std::string> keys;
  for (auto&& label : axesParameters)
  {
    keys.insert(label.first);
  }
  auto it = keys.find(alcKey);
  if (it == keys.end())
  {
    std::string res =
        "Invalid key for axes labels and colors.\nValid keys are: ";
    for (const auto& [key, value] : axesParameters)
    {
      res += fmt::format("{:s}, ", key);
    }
    if (res.length() >= 2)
    {
      auto pos = res.length() - 2;
      res.replace(pos, 2, "");
    }
    res += "\nUsing the key: xyz";
    std::cout << res << std::endl;
    alcKey = "xyz";
  }
  auto alc = axesParameters[alcKey];

  vtkNew<vtkCameraOrientationRepresentation> rep;

  switch (position)
  {
  case 0:
    rep->AnchorToLowerLeft();
    break;
  case 1:
    rep->AnchorToUpperLeft();
    break;
  case 2:
    rep->AnchorToLowerRight();
    break;
  default:
    rep->AnchorToUpperRight();
  }

  if (!alc.first.empty())
  {
    rep->SetXPlusLabelText(alc.first["+X"]);
    rep->SetXMinusLabelText(alc.first["-X"]);
    rep->SetYPlusLabelText(alc.first["+Y"]);
    rep->SetYMinusLabelText(alc.first["-Y"]);
    rep->SetZPlusLabelText(alc.first["+Z"]);
    rep->SetZMinusLabelText(alc.first["-Z"]);
  }

  if (!alc.second.empty())
  {
    vtkNew<vtkNamedColors> colors;

    rep->SetXAxisColor(colors->GetColor3d(alc.second["+X"]).GetData());
    rep->SetYAxisColor(colors->GetColor3d(alc.second["+Y"]).GetData());
    rep->SetZAxisColor(colors->GetColor3d(alc.second["+Z"]).GetData());
  }

  cow->SetRepresentation(rep);

  cow->Off();

  return cow;
}

} // namespace
