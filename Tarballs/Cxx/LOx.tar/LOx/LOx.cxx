#include <vtkActor.h>
#include <vtkCamera.h>
#include <vtkInteractorStyleSwitch.h>
#include <vtkLookupTable.h>
#include <vtkMultiBlockDataSet.h>
#include <vtkMultiBlockPLOT3DReader.h>
#include <vtkNamedColors.h>
#include <vtkNew.h>
#include <vtkPointSource.h>
#include <vtkPolyDataMapper.h>
#include <vtkProperty.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkRenderer.h>
#include <vtkStreamTracer.h>
#include <vtkStringFormatter.h>
#include <vtkStructuredGrid.h>
#include <vtkStructuredGridGeometryFilter.h>
#include <vtkStructuredGridOutlineFilter.h>
#include <vtkTubeFilter.h>

#include <vtk_cli11.h>
// #include <vtk_fmt.h>
// // clang-format off
// #include VTK_FMT(fmt/format.h)
// // clang-format on

namespace fs = std::filesystem;

// LOx post CFD case study.

int main(int argc, char* argv[])
{
  CLI::App app{"Streamtubes created by using the computational grid"
               " just in front of the post as a source for seeds."};

  // Define options.
  std::string xyzFile;
  app.add_option("xyzFile", xyzFile,
                 "The path to the data file e.g. postxyz.bin.")
      ->required()
      ->check(CLI::ExistingFile);
  std::string qFile;
  app.add_option("qFile", qFile,
                 "The path to the velocity vtu file, e.g. postq.bin.")
      ->required()
      ->check(CLI::ExistingFile);

  CLI11_PARSE(app, argc, argv);

  // Read the data.
  vtkNew<vtkMultiBlockPLOT3DReader> pl3d;
  pl3d->AutoDetectFormatOn();
  pl3d->SetXYZFileName(xyzFile.c_str());
  pl3d->SetQFileName(qFile.c_str());
  pl3d->SetScalarFunctionNumber(153);
  pl3d->SetVectorFunctionNumber(200);
  pl3d->Update();

  vtkStructuredGrid* sg =
      dynamic_cast<vtkStructuredGrid*>(pl3d->GetOutput()->GetBlock(0));

  vtkNew<vtkNamedColors> colors;

  // Blue to red lut.
  vtkNew<vtkLookupTable> lut;
  lut->SetHueRange(0.667, 0.0);

  // The computational planes.
  vtkNew<vtkStructuredGridGeometryFilter> floorComp;
  floorComp->SetExtent(0, 37, 0, 75, 0, 0);
  floorComp->SetInputData(sg);
  floorComp->Update();

  vtkNew<vtkPolyDataMapper> floorMapper;
  floorMapper->SetInputConnection(floorComp->GetOutputPort());
  floorMapper->ScalarVisibilityOff();
  floorMapper->SetLookupTable(lut);

  vtkNew<vtkActor> floorActor;
  floorActor->SetMapper(floorMapper);
  floorActor->GetProperty()->SetRepresentationToWireframe();
  floorActor->GetProperty()->SetColor(colors->GetColor3d("Beige").GetData());
  floorActor->GetProperty()->SetLineWidth(2);

  vtkNew<vtkStructuredGridGeometryFilter> subFloorComp;

  subFloorComp->SetExtent(0, 37, 0, 15, 22, 22);
  subFloorComp->SetInputData(sg);

  vtkNew<vtkPolyDataMapper> subFloorMapper;
  subFloorMapper->SetInputConnection(subFloorComp->GetOutputPort());
  subFloorMapper->SetLookupTable(lut);
  subFloorMapper->SetScalarRange(sg->GetScalarRange());

  vtkNew<vtkActor> subFloorActor;

  subFloorActor->SetMapper(subFloorMapper);

  vtkNew<vtkStructuredGridGeometryFilter> subFloor2Comp;
  subFloor2Comp->SetExtent(0, 37, 60, 75, 22, 22);
  subFloor2Comp->SetInputData(sg);

  vtkNew<vtkPolyDataMapper> subFloor2Mapper;
  subFloor2Mapper->SetInputConnection(subFloor2Comp->GetOutputPort());
  subFloor2Mapper->SetLookupTable(lut);
  subFloor2Mapper->SetScalarRange(sg->GetScalarRange());

  vtkNew<vtkActor> subFloor2Actor;

  subFloor2Actor->SetMapper(subFloor2Mapper);

  vtkNew<vtkStructuredGridGeometryFilter> postComp;

  postComp->SetExtent(10, 10, 0, 75, 0, 37);
  postComp->SetInputData(sg);

  vtkNew<vtkPolyDataMapper> postMapper;
  postMapper->SetInputConnection(postComp->GetOutputPort());
  postMapper->SetLookupTable(lut);
  postMapper->SetScalarRange(sg->GetScalarRange());

  vtkNew<vtkActor> postActor;
  postActor->SetMapper(postMapper);
  postActor->GetProperty()->SetColor(colors->GetColor3d("Beige").GetData());

  vtkNew<vtkStructuredGridGeometryFilter> fanComp;
  fanComp->SetExtent(0, 37, 38, 38, 0, 37);
  fanComp->SetInputData(sg);

  vtkNew<vtkPolyDataMapper> fanMapper;
  fanMapper->SetInputConnection(fanComp->GetOutputPort());
  fanMapper->SetLookupTable(lut);
  fanMapper->SetScalarRange(sg->GetScalarRange());

  vtkNew<vtkActor> fanActor;

  fanActor->SetMapper(fanMapper);
  fanActor->GetProperty()->SetColor(colors->GetColor3d("Beige").GetData());

  // The Streamers.

  // Spherical seed points.
  vtkNew<vtkPointSource> rake;
  rake->SetCenter(-0.74, 0, 0.3);
  rake->SetNumberOfPoints(10);

  // A line of seed points.
  vtkNew<vtkStructuredGridGeometryFilter> seedsComp;
  seedsComp->SetExtent(10, 10, 37, 39, 1, 27);
  seedsComp->SetInputData(sg);

  vtkNew<vtkStreamTracer> streamers;
  streamers->SetInputConnection(pl3d->GetOutputPort());

  // streamers->SetSourceConnection(rake->GetOutputPort());
  streamers->SetSourceConnection(seedsComp->GetOutputPort());
  streamers->SetMaximumPropagation(250);
  streamers->SetInitialIntegrationStep(0.2);
  streamers->SetMinimumIntegrationStep(0.01);
  streamers->SetIntegratorType(2);
  streamers->Update();

  vtkNew<vtkTubeFilter> tubes;
  tubes->SetInputConnection(streamers->GetOutputPort());
  tubes->SetNumberOfSides(8);
  tubes->SetRadius(0.08);
  tubes->SetVaryRadius(0);

  vtkNew<vtkPolyDataMapper> mapTubes;

  mapTubes->SetInputConnection(tubes->GetOutputPort());
  mapTubes->SetScalarRange(sg->GetScalarRange());

  vtkNew<vtkActor> tubesActor;
  tubesActor->SetMapper(mapTubes);

  // The outline.
  vtkNew<vtkStructuredGridOutlineFilter> outline;
  outline->SetInputData(sg);

  vtkNew<vtkPolyDataMapper> outlineMapper;
  outlineMapper->SetInputConnection(outline->GetOutputPort());

  vtkNew<vtkActor> outlineActor;
  outlineActor->SetMapper(outlineMapper);
  outlineActor->GetProperty()->SetColor(colors->GetColor3d("Beige").GetData());

  // Create the graphics stuff.
  vtkNew<vtkRenderer> ren;
  ren->SetBackground(colors->GetColor3d("SlateGray").GetData());
  vtkNew<vtkRenderWindow> renWin;
  renWin->AddRenderer(ren);
  renWin->SetSize(640, 480);
  auto appFn = fs::path((app.get_name())).stem().string();
  renWin->SetWindowName(appFn.c_str());

  vtkNew<vtkRenderWindowInteractor> iren;
  iren->SetRenderWindow(renWin);

  auto is = vtkInteractorStyleSwitch::SafeDownCast(iren->GetInteractorStyle());
  if (is)
  {
    is->SetCurrentStyleToTrackballCamera();
  }

  // Add the actors to the renderer, set the background and size.
  ren->AddActor(outlineActor);
  ren->AddActor(floorActor);
  //  ren->AddActor(subFloorActor);
  //  ren->AddActor(subFloor2Actor);
  ren->AddActor(postActor);
  // ren->AddActor(fanActor);
  ren->AddActor(tubesActor);

  vtkNew<vtkCamera> camera;
  camera->SetFocalPoint(2.47736, -0.150024, 2.42361);
  camera->SetPosition(1.57547, -13.4601, 5.47872);
  camera->SetViewUp(0.00197003, 0.223588, 0.974682);
  camera->SetClippingRange(1, 100);

  ren->SetActiveCamera(camera);

  renWin->Render();
  iren->Start();

  return EXIT_SUCCESS;
}
