#include <vtkActor.h>
#include <vtkCallbackCommand.h>
#include <vtkNamedColors.h>
#include <vtkNew.h>
#include <vtkPolyDataMapper.h>
#include <vtkProperty.h>
#include <vtkProperty2D.h>
#include <vtkRenderWindow.h>
#include <vtkRenderWindowInteractor.h>
#include <vtkRenderer.h>
#include <vtkSliderRepresentation2D.h>
#include <vtkSliderWidget.h>
#include <vtkSphereSource.h>
#include <vtkTextProperty.h>

namespace {
/**
 * @brief The Slider2DProperties struct.
 *
 * These are the default properties.
 * Instantiate the struct and modify as appropriate.
 *
 * @return The properties.
 */
struct Slider2DProperties
{
  struct _Colors
  {
    // The color of the text indicating what the slider controls.
    std::string titleColor{"White"};
    // The color of the text displaying the value.
    std::string labelColor{"White"};
    // The color of the knob that slides.
    std::string sliderColor{"White"};
    // The color of the bar.
    std::string barColor{"White"};
    // The color of the ends of the bar.
    std::string barEndsColor{"White"};
    // The color of the knob when the mouse is held on it.
    std::string selectedColor{"HotPink"};
  };

  struct _Dimensions
  {
    double tubeWidth{0.008};
    double sliderLength{0.01};
    double sliderWidth{0.02};
    double endCapLength{0.005};
    double endCapWidth{0.05};
    double titleHeight{0.03};
    double labelHeight{0.025};
  };

  struct _Position
  {
    int coordinateSystem = VTK_NORMALIZED_VIEWPORT;
    std::array<double, 2> point1{0.1, 0.1};
    std::array<double, 2> point2{0.9, 0.1};
  };

  struct _Range
  {
    double minimumValue{0.0};
    double maximumValue{1.0};
    double value{0.0};
  };

  struct _Text
  {
    // Font families are: Ariel, Courier and Times
    std::string title{};
    std::string titleFontFamily{"Arial"};
    bool titleBold{true};
    bool titleItalic{false};
    bool titleShadow{true};
    std::string labelFontFamily{"Arial"};
    bool labelBold{true};
    bool labelItalic{false};
    bool labelShadow{true};
  };

  struct _Colors Colors;
  struct _Dimensions Dimensions;
  struct _Position Position;
  struct _Range Range;
  struct _Text Text;
};

/**
 * @brief MakeSlider2DProperties
 *
 * This applies more specific values to the default Slider2DProperties.
 *
 * @return The slider 2D properties.
 */
Slider2DProperties MakeSlider2DProperties();

/**
 * @brief Make2DSliderWidget
 *
 * Make a 2D slider widget.
 *
 * @param properties The 2D slider properties.
 * @param iren The vtkInteractor.
 * @return The slider widget.
 */
vtkNew<vtkSliderWidget> Make2DSliderWidget(Slider2DProperties const& properties,
                                           vtkRenderWindowInteractor* iren);

// This does the actual work.
// Callback for the interaction.
class vtkSliderCallback : public vtkCommand
{
public:
  static vtkSliderCallback* New()
  {
    return new vtkSliderCallback;
  }
  virtual void Execute(vtkObject* caller, unsigned long, void*)
  {
    vtkSliderWidget* sliderWidget = reinterpret_cast<vtkSliderWidget*>(caller);
    auto level = static_cast<int>(vtkMath::Round(
        static_cast<vtkSliderRepresentation*>(sliderWidget->GetRepresentation())
            ->GetValue()));
    this->SphereSource->SetPhiResolution(level);
    this->SphereSource->SetThetaResolution(level);
    sliderWidget->GetSliderRepresentation()->SetValue(level);
  }
  vtkSliderCallback() : SphereSource(0)
  {
  }
  vtkSphereSource* SphereSource;
};
} // namespace

int main(int, char*[])
{
  vtkNew<vtkNamedColors> colors;

  // A sphere.
  vtkNew<vtkSphereSource> sphereSource;
  sphereSource->SetCenter(0.0, 0.0, 0.0);
  sphereSource->SetRadius(4.0);

  vtkNew<vtkPolyDataMapper> mapper;
  mapper->SetInputConnection(sphereSource->GetOutputPort());

  vtkNew<vtkActor> actor;
  actor->SetMapper(mapper);
  actor->GetProperty()->SetInterpolationToFlat();
  actor->GetProperty()->SetColor(colors->GetColor3d("MistyRose").GetData());
  actor->GetProperty()->SetEdgeColor(colors->GetColor3d("Tomato").GetData());
  actor->GetProperty()->EdgeVisibilityOn();

  // A renderer and render window.
  vtkNew<vtkRenderer> renderer;
  vtkNew<vtkRenderWindow> renderWindow;
  renderWindow->AddRenderer(renderer);
  renderWindow->SetWindowName("Slider2D");
  renderWindow->SetSize(640, 480);

  // An interactor
  vtkNew<vtkRenderWindowInteractor> renderWindowInteractor;
  renderWindowInteractor->SetRenderWindow(renderWindow);

  // Add the actors to the scene.
  renderer->AddActor(actor);
  renderer->SetBackground(colors->GetColor3d("SlateGray").GetData());

  // Render an image (lights and cameras are created automatically).
  renderWindow->Render();

  auto sp = MakeSlider2DProperties();
  sp.Range.minimumValue = 3;
  sp.Range.maximumValue = 20;
  sp.Range.value = 5;
  sp.Text.title = "Sphere Resolution";

  auto sliderWidget = Make2DSliderWidget(sp, renderWindowInteractor);
  vtkNew<vtkSliderCallback> callback;
  callback->SphereSource = sphereSource;

  sliderWidget->AddObserver(vtkCommand::InteractionEvent, callback);

  renderWindowInteractor->Initialize();
  renderWindow->Render();

  renderWindowInteractor->Start();

  return EXIT_SUCCESS;
}

namespace {

Slider2DProperties MakeSlider2DProperties()
{
  auto sp = Slider2DProperties();

  // Set color properties:
  // Change the color of the knob that slides.
  sp.Colors.sliderColor = "Green";
  // Change the color of the text indicating what the slider controls.
  sp.Colors.titleColor = "AliceBlue";
  // Change the color of the text displaying the value.
  sp.Colors.labelColor = "AliceBlue";
  // Change the color of the knob when the mouse is held on it.
  sp.Colors.selectedColor = "DeepPink";
  // Change the color of the bar.
  sp.Colors.barColor = "MistyRose";
  // Change the color of the ends of the bar.
  sp.Colors.barEndsColor = "Yellow";
  sp.Dimensions.sliderLength = 0.05;
  sp.Dimensions.sliderWidth = 0.025;
  sp.Dimensions.endCapLength = 0.02;
  sp.Dimensions.titleHeight = 0.045;
  sp.Dimensions.labelHeight = 0.035;
  sp.Position.point1 = std::array<double, 2>{0.3, 0.1};
  sp.Position.point2 = std::array<double, 2>{0.7, 0.1};

  return sp;
}

vtkNew<vtkSliderWidget> Make2DSliderWidget(Slider2DProperties const& properties,
                                           vtkRenderWindowInteractor* iren)
{
  vtkNew<vtkNamedColors> colors;

  vtkNew<vtkSliderRepresentation2D> sliderRep;

  sliderRep->SetMinimumValue(properties.Range.minimumValue);
  sliderRep->SetMaximumValue(properties.Range.maximumValue);
  sliderRep->SetValue(properties.Range.value);
  sliderRep->SetTitleText(properties.Text.title.c_str());
  sliderRep->SetTubeWidth(properties.Dimensions.tubeWidth);
  sliderRep->SetSliderLength(properties.Dimensions.sliderLength);
  sliderRep->SetSliderWidth(properties.Dimensions.sliderWidth);
  sliderRep->SetEndCapLength(properties.Dimensions.endCapLength);
  sliderRep->SetEndCapWidth(properties.Dimensions.endCapWidth);
  sliderRep->SetTitleHeight(properties.Dimensions.titleHeight);
  sliderRep->SetLabelHeight(properties.Dimensions.labelHeight);

  // Set the color properties.
  sliderRep->GetTitleProperty()->SetColor(
      colors->GetColor3d(properties.Colors.titleColor).GetData());
  sliderRep->GetLabelProperty()->SetColor(
      colors->GetColor3d(properties.Colors.labelColor).GetData());
  sliderRep->GetTubeProperty()->SetColor(
      colors->GetColor3d(properties.Colors.barColor).GetData());
  sliderRep->GetCapProperty()->SetColor(
      colors->GetColor3d(properties.Colors.barEndsColor).GetData());
  sliderRep->GetSliderProperty()->SetColor(
      colors->GetColor3d(properties.Colors.sliderColor).GetData());
  sliderRep->GetSelectedProperty()->SetColor(
      colors->GetColor3d(properties.Colors.selectedColor).GetData());

  // Set the position.
  sliderRep->GetPoint1Coordinate()->SetCoordinateSystem(
      properties.Position.coordinateSystem);
  sliderRep->GetPoint1Coordinate()->SetValue(properties.Position.point1.data());
  sliderRep->GetPoint2Coordinate()->SetCoordinateSystem(
      properties.Position.coordinateSystem);
  sliderRep->GetPoint2Coordinate()->SetValue(properties.Position.point2.data());

  std::string titleFontFamily = properties.Text.titleFontFamily;
  if (titleFontFamily == "Courier")
  {
    sliderRep->GetLabelProperty()->SetFontFamilyToCourier();
  }
  else if (titleFontFamily == "Times")
  {
    sliderRep->GetLabelProperty()->SetFontFamilyToTimes();
  }
  else
  {
    sliderRep->GetLabelProperty()->SetFontFamilyToArial();
  }
  sliderRep->GetTitleProperty()->SetBold(properties.Text.titleBold);
  sliderRep->GetTitleProperty()->SetItalic(properties.Text.titleItalic);
  sliderRep->GetTitleProperty()->SetShadow(properties.Text.titleShadow);
  std::string labelFontFamily = properties.Text.labelFontFamily;
  if (labelFontFamily == "Courier")
  {
    sliderRep->GetLabelProperty()->SetFontFamilyToCourier();
  }
  else if (labelFontFamily == "Times")
  {
    sliderRep->GetLabelProperty()->SetFontFamilyToTimes();
  }
  else
  {
    sliderRep->GetLabelProperty()->SetFontFamilyToArial();
  }
  sliderRep->GetLabelProperty()->SetBold(properties.Text.labelBold);
  sliderRep->GetLabelProperty()->SetItalic(properties.Text.labelItalic);
  sliderRep->GetLabelProperty()->SetShadow(properties.Text.labelShadow);

  vtkNew<vtkSliderWidget> widget;
  widget->SetInteractor(iren);
  widget->SetRepresentation(sliderRep);
  widget->EnabledOn();
  widget->SetAnimationModeToAnimate();

  return widget;
}

} // namespace
